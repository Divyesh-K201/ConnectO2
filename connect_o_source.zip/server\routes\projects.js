const express = require('express');
const router = express.Router();
const projectController = require('../controllers/projectController');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

router.get('/', projectController.getAllProjects);
router.get('/my', authenticateToken, projectController.getMyProjects);

router.post('/', authenticateToken, authorizeRole(['TASKMASTER']), projectController.createProject);
router.post('/apply', authenticateToken, authorizeRole(['SOLOPRO']), projectController.applyToProject);
router.post('/accept', authenticateToken, authorizeRole(['TASKMASTER']), projectController.acceptApplication);

module.exports = router;
