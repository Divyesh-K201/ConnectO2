const { Client } = require('pg');

async function createDb() {
  const client = new Client({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'postgres',
    port: 5432,
  });

  try {
    await client.connect();
    console.log('Connected to default postgres database.');
    
    const res = await client.query("SELECT datname FROM pg_database WHERE datname = 'connecto'");
    if (res.rowCount === 0) {
      console.log('Database connecto does not exist. Creating...');
      await client.query('CREATE DATABASE connecto');
      console.log('Database connecto created successfully.');
    } else {
      console.log('Database connecto already exists.');
    }
  } catch (error) {
    console.error('Error creating database:', error);
  } finally {
    await client.end();
  }
}

createDb();
