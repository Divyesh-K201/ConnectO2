import { Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import NotFound from './pages/NotFound'; // I'll create this simple 404
import Navbar from './components/Navbar';

function App() {
    return (
        <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
            <Routes>
                <Route path="/" element={<Landing />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/dashboard/*" element={<Dashboard />} />
                <Route path="*" element={<div className="p-20 text-center"><h1>404 Not Found</h1></div>} />
            </Routes>
        </div>
    );
}

export default App;
