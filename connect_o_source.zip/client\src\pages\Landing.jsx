import Navbar from '../components/Navbar';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const Landing = () => {
    return (
        <div className="min-h-screen bg-slate-50 overflow-hidden font-sans">
            {/* Simple Navbar with Logo */}
            <nav className="relative z-50 w-full px-6 py-4 flex justify-between items-center max-w-7xl mx-auto">
                <div className="flex items-center gap-2">
                    <div className="h-8 w-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-white font-bold">O</div>
                    <div className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600">ConnectO</div>
                </div>
                <div className="flex items-center gap-4">
                    <Link to="/login" className="text-slate-600 hover:text-slate-900 font-medium">Log In</Link>
                </div>
            </nav>

            <main className="pt-16 pb-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto text-center relative z-10">
                <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                >
                    <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-slate-900 mb-6 leading-tight">
                        Where <span className="text-blue-600">TaskMasters</span> <br />
                        meet <span className="text-yellow-500">SoloPros</span>
                    </h1>

                    <p className="mt-6 text-lg text-slate-500 max-w-2xl mx-auto mb-10">
                        The professional platform connecting clients with talented designers and developers.
                        Gamified experience with EXP points, badges, and global leaderboards.
                    </p>

                    <div className="flex flex-col sm:flex-row justify-center gap-4 mb-20">
                        <Link to="/register?role=TASKMASTER" className="px-8 py-3 bg-blue-600 text-white rounded-md font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2 shadow-lg shadow-blue-500/30">
                            <span className="text-xl">👥</span> Sign Up as TaskMaster
                        </Link>
                        <Link to="/register?role=SOLOPRO" className="px-8 py-3 bg-yellow-500 text-white rounded-md font-semibold hover:bg-yellow-600 transition flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/30">
                            <span className="text-xl">🚀</span> Sign Up as SoloPro
                        </Link>
                    </div>

                    {/* Hero Image Mockup */}
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.3, duration: 0.8 }}
                        className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white/50"
                    >
                        <img
                            src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&auto=format&fit=crop&w=2072&q=80"
                            alt="ConnectO Dashboard"
                            className="w-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/50 to-transparent"></div>
                    </motion.div>

                </motion.div>
            </main>

            {/* Background Decoration */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
                <div className="absolute top-[-10%] left-[-10%] w-[40rem] h-[40rem] bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
                <div className="absolute top-[-10%] right-[-10%] w-[40rem] h-[40rem] bg-yellow-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
            </div>
        </div>
    );
};

export default Landing;
