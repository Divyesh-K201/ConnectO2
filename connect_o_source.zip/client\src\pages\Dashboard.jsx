import { useAuth } from '../context/AuthContext';
import Navbar from '../components/Navbar';
import TaskMasterView from '../components/dashboard/TaskMasterView';
import SoloProView from '../components/dashboard/SoloProView';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
    const { user, loading } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        if (!loading && !user) {
            navigate('/login');
        }
    }, [user, loading, navigate]);

    if (loading || !user) {
        return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
    }

    return (
        <div className="min-h-screen bg-slate-50">
            <Navbar />
            <div className="pt-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto pb-12">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900">
                        Hello, <span className="text-primary-600">{user.name}</span>
                    </h1>
                    <p className="text-slate-500">Welcome to your command center.</p>
                </div>

                {user.role === 'TASKMASTER' ? <TaskMasterView /> : <SoloProView />}
            </div>
        </div>
    );
};

export default Dashboard;
