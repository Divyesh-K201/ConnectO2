import { motion } from 'framer-motion';

const ApplicantsView = ({ project, onBack, onHire, onChat }) => {
    // Mock Applicants Data
    const applicants = [
        {
            id: 1,
            name: "Sarah Wilson",
            role: "Motion Graphics Artist",
            rating: 4.9,
            projects: 42,
            bid: 1800,
            time: "2 Weeks",
            avatar: "S",
            letter: "Hi! I specialize in high-conversion animations. I've worked with similar e-commerce brands and can deliver a sleek, modern look that matches your brand guidelines. Check my portfolio for the 'Nike' ad I did recently."
        },
        {
            id: 2,
            name: "David Kim",
            role: "Senior Animator",
            rating: 4.7,
            projects: 156,
            bid: 1500,
            time: "3 Weeks",
            avatar: "D",
            letter: "I am very interested in your project. I have extensive experience in After Effects and Blender. I can create a custom rig for your characters."
        },
        {
            id: 3,
            name: "Emily Chen",
            role: "3D Generalist",
            rating: 5.0,
            projects: 8,
            bid: 2200,
            time: "1 Week",
            avatar: "E",
            letter: "I'm new to ConnectO but have 10 years of industry experience. I can prioritize this project and deliver 4k quality renders. Let's discuss the storyboard."
        }
    ];

    return (
        <div className="bg-slate-50 min-h-screen p-8">
            <div className="max-w-5xl mx-auto">
                <button onClick={onBack} className="mb-6 flex items-center text-slate-500 hover:text-slate-900 font-bold transition">
                    ← Back to Dashboard
                </button>

                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
                        Applicants for <span className="text-teal-600">"{project?.title}"</span>
                        <span className="text-sm bg-teal-100 text-teal-700 px-3 py-1 rounded-full font-bold">{applicants.length} Candidates</span>
                    </h1>
                    <p className="text-slate-500 mt-2">Review proposals and select the best fit. All communication is monitored for safety.</p>
                </div>

                <div className="space-y-6">
                    {applicants.map((app, i) => (
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.1 }}
                            key={app.id}
                            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 hover:shadow-md transition"
                        >
                            <div className="flex flex-col md:flex-row gap-6">
                                {/* Profile Info */}
                                <div className="flex-shrink-0 flex flex-col items-center md:w-48 border-r border-slate-100 pr-6">
                                    <div className="w-20 h-20 bg-gradient-to-br from-slate-700 to-slate-900 rounded-full flex items-center justify-center text-white text-2xl font-bold mb-3 shadow-lg">
                                        {app.avatar}
                                    </div>
                                    <h3 className="font-bold text-slate-900 text-lg text-center">{app.name}</h3>
                                    <p className="text-xs text-slate-500 font-medium mb-2">{app.role}</p>
                                    <div className="flex items-center gap-1 text-amber-500 font-bold text-sm">
                                        ⭐ {app.rating} <span className="text-slate-300">({app.projects} Jobs)</span>
                                    </div>
                                    <button className="mt-4 text-xs font-bold text-teal-600 hover:underline">View Portfolio ↗</button>
                                </div>

                                {/* Proposal Content */}
                                <div className="flex-1 space-y-4">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">Cover Letter</h4>
                                            <p className="text-slate-700 text-sm leading-relaxed italic">"{app.letter}"</p>
                                        </div>
                                        <div className="text-right ml-4">
                                            <div className="text-2xl font-black text-slate-900">${app.bid}</div>
                                            <div className="text-xs text-slate-500 font-bold">in {app.time}</div>
                                        </div>
                                    </div>

                                    {/* Action Area */}
                                    <div className="pt-4 border-t border-slate-100 flex justify-between items-center bg-slate-50/50 -mx-6 -mb-6 p-6 rounded-b-2xl mt-4">
                                        <div className="text-xs text-slate-400 flex items-center gap-2">
                                            <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                                            Online now
                                        </div>
                                        <div className="flex gap-3">
                                            <button
                                                onClick={() => onChat(app)}
                                                className="px-6 py-2.5 bg-white border border-slate-300 text-slate-700 font-bold rounded-xl hover:bg-slate-50 transition shadow-sm"
                                            >
                                                💬 Message
                                            </button>
                                            <button
                                                onClick={() => onHire(app)}
                                                className="px-8 py-2.5 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition shadow-lg shadow-slate-900/20"
                                            >
                                                Hire & Start Project 🚀
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ApplicantsView;
