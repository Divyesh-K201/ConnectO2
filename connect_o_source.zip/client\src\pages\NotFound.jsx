import { Link } from 'react-router-dom';

const NotFound = () => {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50">
            <h1 className="text-6xl font-bold text-slate-900">404</h1>
            <p className="text-xl text-slate-600 mt-4">Page not found.</p>
            <Link to="/" className="mt-8 px-6 py-2 bg-primary-600 text-white rounded-lg">Go Home</Link>
        </div>
    );
};

export default NotFound;
