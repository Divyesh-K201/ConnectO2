import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const WelcomeModal = ({ role, onClose }) => {
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 animate-fade-in">
            <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full text-center relative overflow-hidden">
                <div className="relative z-10">
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                        <svg className="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path>
                        </svg>
                    </div>

                    <h2 className="text-3xl font-bold text-slate-900 mb-2">Welcome to ConnectO!</h2>
                    <p className="text-slate-600 mb-8">
                        Successfully signed up as <span className="font-semibold">{role}</span>
                        <div className="text-sm mt-2 text-slate-500 font-normal">
                            Your account has been created and you're ready to start {role === 'SOLOPRO' ? 'finding amazing projects' : 'hiring top talent'}.
                        </div>
                    </p>

                    <div className="bg-yellow-50 text-yellow-800 text-sm py-2 rounded-lg mb-6 border border-yellow-100">
                        Redirecting to your dashboard in <span className="font-bold">2 seconds...</span>
                    </div>

                    <button
                        onClick={onClose}
                        className={`w-full py-3 rounded-xl font-bold text-white shadow-lg transition transform hover:scale-[1.02] ${role === 'SOLOPRO' ? 'bg-gradient-to-r from-orange-500 to-yellow-500' : 'bg-gradient-to-r from-teal-500 to-emerald-500'}`}
                    >
                        Go to Dashboard →
                    </button>
                </div>
            </div>
        </div>
    );
};

export default WelcomeModal;
