import { createContext, useContext, useState, useEffect } from 'react';
import api from '../api/axios';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const checkUser = async () => {
            const token = localStorage.getItem('token');
            if (token) {
                // If it's a dummy token, restore dummy user
                if (token.startsWith('demo-token-')) {
                    const role = token.includes('taskmaster') ? 'TASKMASTER' : 'SOLOPRO';
                    // Restore name from storage if available
                    const savedName = localStorage.getItem('demoUserName') || 'Demo User';
                    setUser({ name: savedName, role, email: 'demo@connecto.com' });
                    setLoading(false);
                    return;
                }

                try {
                    const { data } = await api.get('/auth/me');
                    setUser(data);
                } catch (err) {
                    if (localStorage.getItem('token')) {
                        console.warn("Auth check failed, possibly offline. Keeping session.");
                        localStorage.removeItem('token');
                        setUser(null);
                    }
                }
            }
            setLoading(false);
        };
        checkUser();
    }, []);

    const login = async (email, password) => {
        try {
            const { data } = await api.post('/auth/login', { email, password });
            localStorage.setItem('token', data.token);
            setUser(data.user);
            return data.user;
        } catch (error) {
            console.warn("Login failed or offline. Using Demo Mode.");
            const isTaskMaster = email.toLowerCase().includes('task');

            // NOTE: For login, we don't treat them as "New" unless explicit logic exists.
            // We assume existing user has stats.
            const demoUser = {
                id: 'demo-123',
                name: 'Demo User',
                email: email,
                role: isTaskMaster ? 'TASKMASTER' : 'SOLOPRO',
            };

            setUser(demoUser);
            localStorage.setItem('demoUserName', 'Demo User');
            localStorage.setItem('token', `demo-token-${isTaskMaster ? 'taskmaster' : 'solopro'}`);
            return demoUser;
        }
    };

    const register = async (userData) => {
        try {
            await api.post('/auth/register', userData);
        } catch (error) {
            console.warn("Registration failed or offline. Using Demo Mode.");

            // FLAG as new user for DataContext to pick up
            localStorage.setItem('isNewViaRegister', 'true');

            const demoUser = {
                id: 'demo-new-123',
                name: userData.name || 'New User',
                email: userData.email,
                role: userData.role || 'SOLOPRO',
            };
            setUser(demoUser);
            localStorage.setItem('demoUserName', userData.name || 'New User');
            localStorage.setItem('token', `demo-token-${userData.role === 'TASKMASTER' ? 'taskmaster' : 'solopro'}`);
            return demoUser;
        }
    };

    const logout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('demoUserName');
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, login, register, logout, loading }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
