const prisma = require('../db');

exports.getProfile = async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        const user = await prisma.user.findUnique({
            where: { id: userId },
            include: { badges: true, reviewsReceived: true }
        });
        if (!user) return res.status(404).json({ message: 'User not found' });

        const { password, ...userData } = user;
        res.json(userData);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching profile' });
    }
};

exports.getLeaderboard = async (req, res) => {
    try {
        const leaders = await prisma.user.findMany({
            where: { role: 'SOLOPRO' },
            orderBy: { exp: 'desc' },
            take: 10,
            select: { id: true, name: true, exp: true, badges: true, avatar: true }
        });
        res.json(leaders);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching leaderboard' });
    }
};
