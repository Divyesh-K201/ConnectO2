const jwt = require('jsonwebtoken');
const prisma = require('../db');

const authenticateToken = async (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) return res.status(401).json({ message: 'Access Denied: No Token Provided' });

    try {
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        req.user = await prisma.user.findUnique({
            where: { id: verified.id },
            select: { id: true, email: true, role: true, name: true } // Don't return password
        });

        if (!req.user) {
            return res.status(404).json({ message: 'User not found' });
        }

        next();
    } catch (err) {
        res.status(403).json({ message: 'Invalid Token' });
    }
};

const authorizeRole = (roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({ message: 'Access Denied: Insufficient Permissions' });
        }
        next();
    };
};

module.exports = { authenticateToken, authorizeRole };
