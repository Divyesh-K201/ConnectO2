import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    return (
        <nav className="fixed w-full z-50 bg-white border-b border-slate-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between h-16 items-center">
                    {/* Logo Section */}
                    <Link to="/" className="flex items-center gap-2">
                        <div className="h-8 w-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-white font-bold">O</div>
                        <div className="flex flex-col">
                            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600 leading-none">ConnectO</span>
                            <span className="text-[0.6rem] text-slate-400 font-medium tracking-wide">Connect • Create • Succeed</span>
                        </div>
                    </Link>

                    {/* Search Bar (Only when logged in or on dash) */}
                    <div className="hidden md:flex flex-1 max-w-lg mx-8">
                        <div className="relative w-full">
                            <span className="absolute left-3 top-2.5 text-slate-400">🔍</span>
                            <input
                                type="text"
                                placeholder="Search projects, designers, or companies..."
                                className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-2 focus:ring-purple-100 transition outline-none text-sm"
                            />
                        </div>
                    </div>

                    {/* Right Actions */}
                    <div className="flex items-center space-x-4">
                        <button className="relative p-2 text-slate-400 hover:text-slate-600">
                            🔔 <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 rounded-full text-[0.6rem] text-white flex items-center justify-center border-2 border-white">3</span>
                        </button>

                        {user ? (
                            <div className="flex items-center gap-3">
                                <div className="h-8 w-8 bg-purple-600 rounded-full text-white flex items-center justify-center font-bold text-sm">
                                    {user.name?.[0] || 'U'}
                                </div>
                                <button onClick={handleLogout} className="text-sm text-slate-500 hover:text-red-500">
                                    Logout
                                </button>
                            </div>
                        ) : (
                            <Link to="/login" className="px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition">
                                Log In
                            </Link>
                        )}
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
