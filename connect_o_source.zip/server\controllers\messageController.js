const prisma = require('../db');
const { checkCommunicationViolation } = require('../utils/communication');

exports.sendMessage = async (req, res) => {
    try {
        const { receiverId, projectId, content } = req.body;
        const senderId = req.user.id;

        // 1. Check Restrictions
        const check = checkCommunicationViolation(content);
        if (check.violation) {
            // Log Violation
            await prisma.violationLog.create({
                data: {
                    userId: senderId,
                    type: 'COMMUNICATION_ATTEMPT',
                    description: `Attempted to send restricted info: ${check.reasons.join(', ')}`
                }
            });

            // Penalize User (Example: Deduct 10 EXP)
            await prisma.user.update({
                where: { id: senderId },
                data: { exp: { decrement: 10 } }
            });

            return res.status(400).json({
                message: 'Message blocked! Private contact exchange is prohibited.',
                reasons: check.reasons
            });
        }

        // 2. Send Message
        const message = await prisma.message.create({
            data: {
                content,
                senderId,
                receiverId,
                projectId
            }
        });

        res.status(201).json(message);

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

exports.getMessages = async (req, res) => {
    try {
        const { projectId } = req.query; // Or use other filters
        const userId = req.user.id;

        // Ensure user is part of the project? (Simplified for now)

        const messages = await prisma.message.findMany({
            where: {
                projectId: parseInt(projectId),
                OR: [
                    { senderId: userId },
                    { receiverId: userId }
                ]
            },
            include: {
                sender: { select: { id: true, name: true, avatar: true } }
            },
            orderBy: { createdAt: 'asc' }
        });

        res.json(messages);

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};
