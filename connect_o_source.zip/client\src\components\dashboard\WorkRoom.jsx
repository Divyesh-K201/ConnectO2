import { useState, useEffect, useRef } from 'react';
import { useData } from '../../context/DataContext';
import { motion } from 'framer-motion';

const WorkRoom = ({ project, userRole, onBack }) => {
    const { activeProjectCheckpoints = [], markCheckpointPaid, addActivity } = useData();

    // Violation System State
    const [violationCount, setViolationCount] = useState(0);
    const [isChatBanned, setIsChatBanned] = useState(false);
    const [messages, setMessages] = useState([
        { id: 1, sender: 'System', text: '🔒 SECURE CONNECTION ESTABLISHED. All communication must remain on ConnectO. External contact sharing is automatically blocked.', type: 'system' }
    ]);
    const [messageInput, setMessageInput] = useState('');
    const [showVideoModal, setShowVideoModal] = useState(false);
    const chatEndRef = useRef(null);

    // Scroll to bottom of chat
    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const isUnlocked = activeProjectCheckpoints[0]?.paid || false;

    // Enhanced Restricted Patterns (Emails, Phones, Socials, Domains)
    const restrictedPatterns = [
        /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/gi, // Emails
        /\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g, // Phone Numbers (Generic)
        /\b\d{10}\b/g, // 10 digit raw
        /(?:whatsapp|telegram|skype|zoom|discord|slack|linkedin|instagram|facebook|twitter)/gi, // App Names
        /(?:g-?meet|teams\.microsoft|webex)/gi, // Meeting Apps
        /https?:\/\/(?!connecto\.com)[^\s]+/gi, // External Links
        /\b(?:gmail|yahoo|hotmail|outlook|protonmail)\b/gi // Email providers
    ];

    const sendMessage = () => {
        if (!isUnlocked) {
            alert('🔒 ACCESS DENIED: Initial Deposit payment required to unlock Secure Chat.');
            return;
        }
        if (!messageInput.trim() || isChatBanned) return;

        // SECURITY SCAN
        const isSuspicious = restrictedPatterns.some(regex => regex.test(messageInput));

        if (isSuspicious) {
            handleViolation();
            setMessageInput('');
            return;
        }

        // 3. ALLOW MESSAGE
        const newMessage = { id: Date.now(), sender: 'You', text: messageInput, type: 'user' };
        setMessages(prev => [...prev, newMessage]);
        setMessageInput('');

        // Mock Reply
        setTimeout(() => {
            setMessages(prev => [...prev, { id: Date.now() + 1, sender: userRole === 'TASKMASTER' ? 'SoloPro' : 'TaskMaster', text: 'Confirmed. I will share the work updates here as soon as they are ready.', type: 'peer' }]);
        }, 1500);
    };

    const handleViolation = () => {
        const newCount = violationCount + 1;
        setViolationCount(newCount);

        let warningMsg = '';
        let severity = 'warning';

        if (newCount === 1) {
            warningMsg = '⚠️ ConnectO Anti-Leak AI (1/3): Sharing external contact info is strictly prohibited. Your message was blocked to protect your security.';
        } else if (newCount === 2) {
            warningMsg = '🚨 FINAL WARNING (2/3): Violation detected. Trust Score deduction pending. Future violations will result in account suspension.';
        } else if (newCount >= 3) {
            warningMsg = '🚫 SECURITY ALERT: Chat privileges suspended. Repeated attempt to bypass platform security detected.';
            setIsChatBanned(true);
            severity = 'danger';
        }

        setMessages(prev => [...prev, {
            id: Date.now(),
            sender: 'SECURITY BOT',
            text: warningMsg,
            type: severity
        }]);
    };

    const handlePay = (id, amount) => {
        // Enforce sequential order
        const checkpointIndex = activeProjectCheckpoints.findIndex(c => c.id === id);
        if (checkpointIndex > 0) {
            const prev = activeProjectCheckpoints[checkpointIndex - 1];
            if (prev.status !== 'completed') {
                alert(`⚠️ You must complete and pay for "${prev.title}" before unlocking this milestone.`);
                return;
            }
        }

        if (confirm(`💰 SECURE ESCROW: Release $${amount}? This amount will be held securely. Unlocks Chat & Meeting.`)) {
            markCheckpointPaid(id);
        }
    };

    return (
        <div className="bg-slate-50 min-h-screen p-6 font-sans">
            <button onClick={onBack} className="mb-4 flex items-center text-slate-500 hover:text-slate-900 font-bold">
                ← Back to Dashboard
            </button>

            {/* Anti-Leak Banner */}
            <div className="bg-slate-900 text-slate-300 p-3 rounded-xl mb-6 flex justify-center items-center text-xs font-medium gap-6 shadow-sm">
                <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span> End-to-End Encrypted</span>
                <span className="flex items-center gap-2">🛡️ ConnectO Anti-Leak AI Active</span>
                <span className="flex items-center gap-2">💳 Payments Held in Escrow</span>
            </div>

            <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6 h-[80vh]">

                {/* Left: Project Checkpoints (HARD RULES) */}
                <div className="lg:col-span-2 space-y-6 flex flex-col">
                    {/* Header */}
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex justify-between items-start">
                        <div>
                            <div className="flex items-center gap-3 mb-1">
                                <h1 className="text-2xl font-bold text-slate-900">{project?.title || 'Project Workspace'}</h1>
                                <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase track-wide ${isUnlocked ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                                    {isUnlocked ? 'Unlocked' : 'Deposit Required'}
                                </span>
                            </div>
                            <p className="text-slate-500 text-sm">Secure WorkRoom ID: #8823-XJ</p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                            <button
                                onClick={() => !isChatBanned && isUnlocked && setShowVideoModal(true)}
                                disabled={isChatBanned || !isUnlocked}
                                className={`px-5 py-3 rounded-xl font-bold shadow-lg transition flex items-center gap-2 ${isChatBanned || !isUnlocked
                                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                                    : 'bg-indigo-600 text-white shadow-indigo-500/30 hover:bg-indigo-700'}`}
                            >
                                {isUnlocked ? '📹 Start Secure Meeting' : '📹 Meeting Locked'}
                            </button>
                            {!isUnlocked && <span className="text-[10px] text-amber-600 font-bold">Unlocks after Milestone 1 pay</span>}
                        </div>
                    </div>

                    {/* Timeline */}
                    <div className="bg-white p-8 rounded-3xl shadow-lg border border-slate-100 flex-1 overflow-auto">
                        <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                            Milestone Workflow
                            <span className="text-xs font-normal text-slate-400 bg-slate-100 px-2 py-1 rounded border border-slate-200">Strict Sequential Enforcement</span>
                        </h2>

                        <div className="space-y-8 relative">
                            <div className="absolute left-4 top-4 bottom-4 w-0.5 bg-slate-100"></div>

                            {activeProjectCheckpoints.map((cp, i) => {
                                // Logic: Is this step accessible?
                                const isLocked = i > 0 && activeProjectCheckpoints[i - 1].status !== 'completed';

                                return (
                                    <div key={cp.id} className={`relative pl-12 transition-opacity duration-500 ${isLocked ? 'opacity-40 grayscale pointer-events-none' : 'opacity-100'}`}>
                                        {/* Status Dot */}
                                        <div className={`absolute left-0 top-1 w-9 h-9 rounded-full border-4 flex items-center justify-center bg-white z-10 transition-colors duration-500 ${cp.status === 'completed' ? 'border-green-500 text-green-500' :
                                            cp.status === 'in-progress' ? 'border-amber-500 text-amber-500' : 'border-slate-300 text-slate-300'
                                            }`}>
                                            {cp.status === 'completed' ? '✓' : i + 1}
                                        </div>

                                        <div className={`p-5 rounded-2xl border transition-all duration-300 ${cp.status === 'in-progress' ? 'bg-amber-50 border-amber-200 shadow-md transform scale-[1.01]' :
                                            cp.status === 'completed' ? 'bg-green-50 border-green-200' : 'bg-white border-slate-200'
                                            }`}>
                                            <div className="flex justify-between items-center">
                                                <div>
                                                    <h3 className={`font-bold text-lg ${cp.status === 'completed' ? 'text-green-800' : 'text-slate-800'}`}>{cp.title}</h3>
                                                    <div className="flex items-center gap-3 mt-1">
                                                        <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-sm">${cp.amount}</span>
                                                        {isLocked && <span className="text-xs text-red-400 font-bold flex items-center gap-1">🔒 Locked</span>}
                                                        {cp.description && <span className="text-xs text-indigo-500 font-medium italic">({cp.description})</span>}
                                                    </div>
                                                </div>

                                                {/* Action Button */}
                                                {userRole === 'TASKMASTER' ? (
                                                    cp.status === 'completed' ? (
                                                        <span className="flex items-center gap-1 text-green-700 font-bold bg-white px-3 py-1 rounded-lg border border-green-200 text-sm">
                                                            Paid & Approved 💸
                                                        </span>
                                                    ) : (
                                                        <button
                                                            onClick={() => handlePay(cp.id, cp.amount)}
                                                            className={`px-5 py-2.5 rounded-xl font-bold shadow-sm transition text-sm ${cp.status === 'locked' || isLocked
                                                                ? 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none'
                                                                : 'bg-green-600 text-white hover:bg-green-700 hover:shadow-green-500/30'
                                                                }`}
                                                        >
                                                            {cp.status === 'in-progress' ? 'Release Funds 💳' : 'Fund Milestone 🔒'}
                                                        </button>
                                                    )
                                                ) : (
                                                    <span className={`px-4 py-2 font-bold rounded-lg text-sm ${cp.status === 'completed' ? 'text-green-700 bg-green-100' :
                                                        cp.status === 'in-progress' ? 'text-amber-700 bg-amber-100' : 'text-slate-400 bg-slate-50'
                                                        }`}>
                                                        {cp.status === 'completed' ? 'Paid ✅' : cp.status === 'in-progress' ? 'Work In Progress ⏳' : 'Pending Funding'}
                                                    </span>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>

                {/* Right: Secure Chat (STRICT) */}
                <div className="bg-white rounded-2xl shadow-xl border border-slate-200 flex flex-col overflow-hidden h-full relative">
                    <div className={`p-4 text-white flex justify-between items-center transition-colors ${isChatBanned ? 'bg-red-600' : 'bg-slate-900'}`}>
                        <div className="font-bold flex items-center gap-2">
                            {isChatBanned ? '🚫 CHAT SUSPENDED' : (
                                <>
                                    <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                                    Secure Chat
                                </>
                            )}
                        </div>
                        <span className="text-[10px] bg-white/10 px-2 py-1 rounded border border-white/20 uppercase">
                            AI Mod Active
                        </span>
                    </div>

                    {!isUnlocked && (
                        <div className="absolute inset-x-0 bottom-0 top-14 bg-white/60 backdrop-blur-sm z-20 flex flex-col items-center justify-center p-8 text-center">
                            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-3xl shadow-lg mb-4 border border-slate-100">🔒</div>
                            <h3 className="font-black text-slate-900 text-lg mb-2 uppercase">Chat & Meetings Locked</h3>
                            <p className="text-slate-600 text-xs font-medium leading-relaxed">
                                To protect our community, communication is unlocked only after the <span className="text-indigo-600 font-bold">Initial Milestone (Deposit)</span> is funded by the TaskMaster.
                            </p>
                            {userRole === 'TASKMASTER' && (
                                <button
                                    onClick={() => handlePay(activeProjectCheckpoints[0].id, activeProjectCheckpoints[0].amount)}
                                    className="mt-6 px-6 py-2.5 bg-green-600 text-white rounded-xl font-bold shadow-lg shadow-green-500/30 hover:bg-green-700"
                                >
                                    Fund Milestone 1 to Unlock
                                </button>
                            )}
                        </div>
                    )}

                    <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50 relative">
                        {messages.map((msg) => (
                            <div key={msg.id} className={`flex ${msg.sender === 'You' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-[85%] rounded-2xl p-3 text-sm shadow-sm ${msg.type === 'system' ? 'w-full bg-blue-50 text-blue-800 text-center font-bold text-[10px] border border-blue-100' :
                                    msg.type === 'warning' ? 'w-full bg-amber-50 border border-amber-200 text-amber-800 text-center font-semibold' :
                                        msg.type === 'danger' ? 'w-full bg-red-50 border border-red-200 text-red-700 text-center font-bold' :
                                            msg.sender === 'You' ? 'bg-indigo-600 text-white rounded-br-none' :
                                                'bg-white border border-slate-200 text-slate-700 rounded-bl-none'
                                    }`}>
                                    {msg.text}
                                </div>
                            </div>
                        ))}
                        <div ref={chatEndRef}></div>
                    </div>

                    <div className="p-4 bg-white border-t border-slate-100">
                        {isChatBanned ? (
                            <div className="text-red-500 font-bold text-center text-sm p-2 bg-red-50 rounded-lg">
                                Access Blocked due to Violations.
                            </div>
                        ) : (
                            <>
                                <div className="flex gap-2">
                                    <input
                                        type="text"
                                        disabled={!isUnlocked}
                                        className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition text-sm disabled:opacity-50"
                                        placeholder={isUnlocked ? "Type a message..." : "Chat Locked"}
                                        value={messageInput}
                                        onChange={e => setMessageInput(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && sendMessage()}
                                    />
                                    <button
                                        onClick={sendMessage}
                                        disabled={!isUnlocked}
                                        className={`p-3 rounded-xl transition shadow-lg ${isUnlocked ? 'bg-indigo-600 text-white shadow-indigo-500/30 hover:bg-indigo-700' : 'bg-slate-200 text-slate-400'}`}
                                    >
                                        ➤
                                    </button>
                                </div>
                                <div className="text-[10px] text-center text-slate-400 mt-2">
                                    ConnectO Anti-Leak AI is monitoring this chat.
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>

            {/* Google Meet Style Video Modal */}
            {showVideoModal && (
                <VideoMeetingModal userRole={userRole} onClose={() => setShowVideoModal(false)} />
            )}
        </div>
    );
};

// Extracted for cleanliness and logic
const VideoMeetingModal = ({ userRole, onClose }) => {
    const videoRef = useRef(null);
    const [stream, setStream] = useState(null);
    const [isMuted, setIsMuted] = useState(false);
    const [isCamOff, setIsCamOff] = useState(false);
    const [isScreenSharing, setIsScreenSharing] = useState(false);
    const [isPeerConnected, setIsPeerConnected] = useState(false);

    useEffect(() => {
        startCamera();

        // Mock peer joining after 5 seconds
        const timer = setTimeout(() => {
            setIsPeerConnected(true);
        }, 5000);

        return () => {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }
            clearTimeout(timer);
        };
    }, []);

    const startCamera = async () => {
        try {
            const mediaStream = await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: true
            });
            setStream(mediaStream);
            if (videoRef.current) {
                videoRef.current.srcObject = mediaStream;
            }
        } catch (err) {
            console.error("Error accessing media devices:", err);
            alert("Could not access camera/microphone. Please check permissions.");
        }
    };

    const toggleMic = () => {
        if (stream) {
            const audioTrack = stream.getAudioTracks()[0];
            if (audioTrack) {
                audioTrack.enabled = !audioTrack.enabled;
                setIsMuted(!audioTrack.enabled);
            }
        }
    };

    const toggleCamera = () => {
        if (stream) {
            const videoTrack = stream.getVideoTracks()[0];
            if (videoTrack) {
                videoTrack.enabled = !videoTrack.enabled;
                setIsCamOff(!videoTrack.enabled);
            }
        }
    };

    const handleEndCall = () => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-[#202124] z-[100] flex flex-col font-sans text-white">
            {/* Top Bar */}
            <div className="p-4 flex justify-between items-center bg-[#202124]">
                <div className="flex items-center gap-3">
                    <span className="bg-red-500 w-2 h-2 rounded-full animate-pulse"></span>
                    <span className="text-sm font-medium">ConnectO Secure Meeting | Project #8823-XJ</span>
                </div>
                <div className="flex items-center gap-4 text-xs font-bold">
                    <span className="bg-white/10 px-3 py-1 rounded border border-white/10 uppercase tracking-widest">Recording for Compliance</span>
                </div>
            </div>

            {/* Video Grid */}
            <div className="flex-1 p-6 flex items-center justify-center relative overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-6xl h-full max-h-[70vh]">
                    {/* User Video */}
                    <div className="bg-slate-800 rounded-2xl relative overflow-hidden border-2 border-slate-700 shadow-2xl flex items-center justify-center">
                        {isCamOff ? (
                            <div className="text-center">
                                <div className="w-24 h-24 bg-slate-700 rounded-full mx-auto flex items-center justify-center text-3xl mb-4">👤</div>
                                <div className="font-bold">You (Camera Off)</div>
                            </div>
                        ) : (
                            <video
                                ref={videoRef}
                                autoPlay
                                playsInline
                                muted
                                className="w-full h-full object-cover mirror transform -scale-x-100"
                            />
                        )}
                        <div className="absolute bottom-4 left-4 bg-black/40 backdrop-blur-md px-3 py-1 rounded-lg text-sm font-bold flex items-center gap-2">
                            <span>You</span>
                            {isMuted && <span className="text-red-400">🔇</span>}
                        </div>
                    </div>

                    {/* Peer Video (Mock) */}
                    <div className="bg-slate-800 rounded-2xl relative overflow-hidden border-2 border-slate-700 shadow-2xl flex items-center justify-center">
                        {isPeerConnected ? (
                            <div className="w-full h-full bg-indigo-900/20 flex flex-col items-center justify-center relative">
                                {/* Mock Video Feed Placeholder */}
                                <div className="w-24 h-24 bg-indigo-500 rounded-full flex items-center justify-center text-3xl font-bold border-4 border-indigo-400">TM</div>
                                <p className="mt-4 font-bold text-indigo-100">TaskMaster (Live)</p>
                                <div className="absolute top-4 right-4 bg-green-500/80 px-2 py-0.5 rounded text-[10px] font-black uppercase">Active Feed</div>
                            </div>
                        ) : (
                            <div className="text-center">
                                <div className="w-24 h-24 bg-slate-700 rounded-full mx-auto flex items-center justify-center text-3xl mb-4 animate-pulse">👥</div>
                                <div className="font-bold text-slate-400 italic">Waiting for Client to join...</div>
                                <p className="text-[10px] text-slate-500 mt-2">Connecting to Secure Gateway</p>
                            </div>
                        )}
                        <div className="absolute bottom-4 left-4 bg-black/40 backdrop-blur-md px-3 py-1 rounded-lg text-sm font-bold">
                            {userRole === 'SOLOPRO' ? 'TaskMaster' : 'SoloPro'}
                        </div>
                    </div>
                </div>

                {/* Secure Badge overlay */}
                <div className="absolute bottom-8 right-8 pointer-events-none opacity-50">
                    <div className="bg-green-500/10 border border-green-500/20 p-4 rounded-xl flex items-center gap-3">
                        <div className="text-2xl">🛡️</div>
                        <div className="text-left">
                            <div className="text-xs font-black text-green-400 uppercase">E2E Encrypted</div>
                            <div className="text-[10px] text-green-300">Monitored for anti-leak policy</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Bottom Controls */}
            <div className="h-24 bg-[#202124] flex items-center justify-between px-10 border-t border-white/5">
                <div className="text-sm font-medium w-48 hidden lg:block">
                    {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} | meeting-room-xyz
                </div>

                <div className="flex items-center gap-4">
                    <button
                        onClick={toggleMic}
                        className={`w-12 h-12 rounded-full flex items-center justify-center text-xl transition-all ${isMuted ? 'bg-red-500 hover:bg-red-600' : 'bg-slate-700 hover:bg-slate-600'}`}
                        title={isMuted ? 'Unmute' : 'Mute'}
                    >
                        {isMuted ? '🔇' : '🎤'}
                    </button>
                    <button
                        onClick={toggleCamera}
                        className={`w-12 h-12 rounded-full flex items-center justify-center text-xl transition-all ${isCamOff ? 'bg-red-500 hover:bg-red-600' : 'bg-slate-700 hover:bg-slate-600'}`}
                        title={isCamOff ? 'Turn on camera' : 'Turn off camera'}
                    >
                        {isCamOff ? '🚫' : '📹'}
                    </button>

                    <button
                        onClick={() => setIsScreenSharing(!isScreenSharing)}
                        className={`w-12 h-12 rounded-full flex items-center justify-center text-xl transition-all ${isScreenSharing ? 'bg-indigo-500' : 'bg-slate-700 hover:bg-slate-600'}`}
                    >
                        🖥️
                    </button>

                    <button
                        className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center text-xl hover:bg-slate-600 transition"
                        title="More options"
                    >
                        ⋮
                    </button>

                    <button
                        onClick={handleEndCall}
                        className="px-8 h-12 bg-red-600 hover:bg-red-700 rounded-full flex items-center justify-center gap-2 font-bold transition shadow-xl shadow-red-900/20"
                    >
                        <span className="text-xl">📞</span> End Call
                    </button>
                </div>

                <div className="flex items-center gap-2 w-48 justify-end">
                    <button className="w-10 h-10 hover:bg-white/5 rounded-full flex items-center justify-center">ℹ️</button>
                    <button className="w-10 h-10 hover:bg-white/5 rounded-full flex items-center justify-center">👥</button>
                    <button className="w-10 h-10 hover:bg-white/5 rounded-full flex items-center justify-center">💬</button>
                </div>
            </div>
        </div>
    );
};

export default WorkRoom;
