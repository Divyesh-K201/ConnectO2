const prisma = require('../db');

exports.createProject = async (req, res) => {
    try {
        const { title, description, budget, deadline } = req.body;
        const clientId = req.user.id;

        const project = await prisma.project.create({
            data: {
                title,
                description,
                budget: parseFloat(budget),
                deadline: new Date(deadline),
                clientId,
                status: 'OPEN',
                payment: {
                    create: {
                        amount: parseFloat(budget),
                        status: 'LOCKED',
                        payerId: clientId
                    }
                }
            }
        });

        res.status(201).json(project);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating project' });
    }
};

exports.getAllProjects = async (req, res) => {
    try {
        const projects = await prisma.project.findMany({
            where: { status: 'OPEN' },
            include: {
                client: { select: { name: true, creditScore: true, badges: true } }
            },
            orderBy: { createdAt: 'desc' }
        });
        res.json(projects);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching projects' });
    }
};

exports.getMyProjects = async (req, res) => {
    try {
        const userId = req.user.id;
        const projects = await prisma.project.findMany({
            where: {
                OR: [
                    { clientId: userId },
                    { workerId: userId }
                ]
            },
            include: { applications: true }
        });
        res.json(projects);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching projects' });
    }
};

exports.applyToProject = async (req, res) => {
    try {
        const { projectId, coverLetter, quote } = req.body;
        const workerId = req.user.id;

        const application = await prisma.application.create({
            data: {
                projectId: parseInt(projectId),
                workerId,
                coverLetter,
                quote: parseFloat(quote)
            }
        });

        res.status(201).json(application);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error applying' });
    }
};

exports.acceptApplication = async (req, res) => {
    try {
        const { applicationId } = req.body;

        const application = await prisma.application.findUnique({
            where: { id: parseInt(applicationId) },
            include: { project: true }
        });

        if (!application) return res.status(404).json({ message: 'Application not found' });

        // Authorization check
        if (application.project.clientId !== req.user.id) {
            return res.status(403).json({ message: 'Not your project' });
        }

        // Update Project
        const updatedProject = await prisma.project.update({
            where: { id: application.project.id },
            data: {
                status: 'IN_PROGRESS',
                workerId: application.workerId,
                // Update Payment payee
                payment: {
                    update: {
                        payeeId: application.workerId
                    }
                }
            }
        });

        // Update Application Status
        await prisma.application.update({
            where: { id: application.id },
            data: { status: 'ACCEPTED' }
        });

        res.json(updatedProject);

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error accepting application' });
    }
};
