import { createContext, useContext, useState, useEffect } from 'react';

const DataContext = createContext();

export const DataProvider = ({ children }) => {
    // Initial Mock Data
    const initialProjects = [
        {
            id: 101,
            title: 'E-commerce Website Redesign',
            type: 'Web Design',
            desc: 'Looking for a talented designer to redesign our e-commerce platform. Need modern UI/UX with focus on conversion optimization.',
            budget: '2000-5000',
            expiry: '15/03/2024',
            applicants: 12,
            status: 'Active',
            client: 'TechCorp Solutions',
            tags: ['UI/UX Design', 'Figma', 'Prototyping']
        },
        {
            id: 102,
            title: 'Mobile App Development',
            type: 'Mobile Development',
            desc: 'Seeking React Native developer for fitness tracking app. Must have experience with health APIs and real-time data.',
            budget: '8000-12000',
            expiry: '01/04/2024',
            applicants: 8,
            status: 'Active',
            client: 'FitLife Startup',
            tags: ['React Native', 'TypeScript', 'API Integration']
        },
        {
            id: 103,
            title: 'Brand Identity Design',
            type: 'Branding',
            desc: 'New fintech company needs complete brand identity including logo, color palette, and brand guidelines.',
            budget: '1500-3000',
            expiry: '01/03/2024',
            applicants: 15,
            status: 'Active',
            client: 'PayFlow Inc',
            tags: ['Logo Design', 'Branding', 'Illustrator']
        },
    ];

    const initialInternships = [
        { id: 1, role: 'React Developer', company: 'TechFlow', applicants: 14, days: 2 },
        { id: 2, role: 'UI Designer', company: 'CreativeMinds', applicants: 8, days: 5 }
    ];

    const initialCourses = [
        { 
            id: 1, 
            title: 'Advanced UI Design Principles', 
            price: 49.99, 
            enrolled: 125, 
            students: [
                { name: 'Alice Johnson', email: 'alice.j@example.com', date: '2024-02-10' },
                { name: 'Marcus Smith', email: 'marcus.s@example.com', date: '2024-02-12' },
                { name: 'Sarah Wilson', email: 'sarah.w@example.com', date: '2024-02-15' }
            ] 
        }
    ];

    const initialStats = {
        projects: 0,
        earned: 0,
        level: 1,
        exp: 0,
        badges: []
    };

    // Mock SoloPros for TaskMaster View
    const initialSoloPros = [
        { id: 'sp1', name: 'Sarah Wilson', role: 'UI/UX Designer', exp: 1250, trustScore: 98, rating: '4.9', tags: ['UI/UX Design', 'Figma', 'React'], avatar: 'SW', matchWeight: 100 },
        { id: 'sp2', name: 'Mike Chen', role: 'Frontend Developer', exp: 2100, trustScore: 92, rating: '4.8', tags: ['React', 'TypeScript', 'Tailwind'], avatar: 'MC', matchWeight: 100 },
        { id: 'sp3', name: 'Lisa Rodriguez', role: 'Graphic Designer', exp: 1800, trustScore: 95, rating: '4.7', tags: ['Photoshop', 'Branding', 'Illustrator'], avatar: 'LR', matchWeight: 100 },
        { id: 'sp4', name: 'Alex Rivera', role: 'Backend Engineer', exp: 3500, trustScore: 99, rating: '5.0', tags: ['Node.js', 'MongoDB', 'Python'], avatar: 'AR', matchWeight: 100 },
        { id: 'sp5', name: 'Emma Watson', role: 'Mobile Developer', exp: 900, trustScore: 85, rating: '4.5', tags: ['React Native', 'Flutter'], avatar: 'EW', matchWeight: 100 },
    ];

    // State
    const [projects, setProjects] = useState(() => {
        const saved = localStorage.getItem('connecto_projects');
        return saved ? JSON.parse(saved) : initialProjects;
    });
    const [internships, setInternships] = useState(() => {
        const saved = localStorage.getItem('connecto_internships');
        return saved ? JSON.parse(saved) : initialInternships;
    });
    const [courses, setCourses] = useState(() => {
        const saved = localStorage.getItem('connecto_courses');
        return saved ? JSON.parse(saved) : initialCourses;
    });
    const [soloPros, setSoloPros] = useState(initialSoloPros);
    const [userStats, setUserStats] = useState(initialStats);
    const [isNewUser, setIsNewUser] = useState(false);

    // Two-sided Enquiry & Application Tracking
    const [enquiries, setEnquiries] = useState([]);
    const [applications, setApplications] = useState([]);
    const [rejections, setRejections] = useState([]); // Store IDs to lower priority but not hide

    // Activity Log
    const [activities, setActivities] = useState([
        { text: 'ConnectO Security Engine Active 🛡️', time: 'System', color: 'bg-indigo-500' },
        { text: 'Welcome to ConnectO!', time: 'Just now', color: 'bg-teal-500' }
    ]);

    // Checkpoints for the "Workroom" (Mocked for a specific active project)
    const [activeProjectCheckpoints, setActiveProjectCheckpoints] = useState([
        { id: 1, title: 'Deposit & Requirement Kickoff', status: 'in-progress', paid: false, amount: 500, description: 'Unlocks Secure Chat & Meeting' },
        { id: 2, title: 'Initial Wireframes', status: 'locked', paid: false, amount: 500 },
        { id: 3, title: 'Development Phase', status: 'locked', paid: false, amount: 1500 },
        { id: 4, title: 'Final Delivery', status: 'locked', paid: false, amount: 1000 },
    ]);

    // --- Core Logic ---

    // OLX-Style Recommendation Engine (Weighted Matching)
    const getRecommendations = (type, userInterests = []) => {
        let items = type === 'PROJECT' ? projects : soloPros;

        return items.map(item => {
            let weight = 100;
            const itemTags = item.tags || (type === 'PROJECT' ? [item.type] : []);

            // Tag matching
            const matches = itemTags.filter(tag => userInterests.includes(tag)).length;
            weight += matches * 20;

            // EXP/Trust matching
            if (item.exp) weight += (item.exp / 100);
            if (item.trustScore) weight += item.trustScore;

            // Rejection Penalty (Lower priority but still visible)
            if (rejections.includes(item.id)) weight -= 50;

            return { ...item, matchWeight: weight };
        }).sort((a, b) => b.matchWeight - a.matchWeight);
    };

    const handleEnquiry = (id, fromRole, toName) => {
        const newEnquiry = { id: Date.now(), targetId: id, from: fromRole, targetName: toName, status: 'PENDING', createdAt: new Date() };
        setEnquiries(prev => [newEnquiry, ...prev]);
        addActivity(`Sent Secure Enquiry to ${toName} 📬`);
    };

    const handleApply = (item, fromRole) => {
        const newApp = { id: Date.now(), itemId: item.id, title: item.title || item.name, from: fromRole, status: 'SENT', createdAt: new Date() };
        setApplications(prev => [newApp, ...prev]);
        addActivity(`Applied to ${item.title || item.name} 🚀`);
    };

    const handleReject = (id) => {
        setRejections(prev => [...prev, id]);
        addActivity(`Not interested in ID#${id}. Suggestions updated.`);
    };

    // Initialize for New User (Reset stats)
    useEffect(() => {
        const isNew = localStorage.getItem('isNewViaRegister');
        if (isNew === 'true') {
            setIsNewUser(true);
            setUserStats({ projects: 0, earned: 0, level: 1, exp: 0, badges: [] });
            // Do NOT clear projects/internships here, because they are global marketplace listings.
        }
    }, []);

    const addProject = (project) => {
        const newProject = { ...project, id: Date.now(), applicants: 0, status: 'Active' };
        const updated = [newProject, ...projects];
        setProjects(updated);
        localStorage.setItem('connecto_projects', JSON.stringify(updated));
        addActivity(`Posted new project: "${project.title}"`);
    };

    const addInternship = (internship) => {
        const newIntern = { ...internship, id: Date.now(), applicants: 0, days: 0 };
        const updated = [newIntern, ...internships];
        setInternships(updated);
        localStorage.setItem('connecto_internships', JSON.stringify(updated));
        addActivity(`Posted new internship: "${internship.role}"`);
    };

    const addCourse = (course) => {
        const newCourse = { ...course, id: Date.now(), enrolled: 0, students: [] };
        const updated = [newCourse, ...courses];
        setCourses(updated);
        localStorage.setItem('connecto_courses', JSON.stringify(updated));
        addActivity(`Uploaded new course: "${course.title}"`);
    };

    const addActivity = (text) => {
        setActivities([{ text, time: 'Just now', color: 'bg-blue-500' }, ...activities]);
    };

    const markCheckpointPaid = (id) => {
        setActiveProjectCheckpoints(prev => prev.map(cp =>
            cp.id === id ? { ...cp, paid: true, status: 'completed' } : cp
        ));
        // Unlock next
        const index = activeProjectCheckpoints.findIndex(c => c.id === id);
        if (index !== -1 && index < activeProjectCheckpoints.length - 1) {
            const nextId = activeProjectCheckpoints[index + 1].id;
            setActiveProjectCheckpoints(prev => prev.map(cp =>
                cp.id === nextId ? { ...cp, status: 'in-progress' } : cp
            ));
        }
        addActivity(`Milestone payment released: $${activeProjectCheckpoints.find(c => c.id === id).amount}. Chat Unlocked! 🔓`);
    };

    return (
        <DataContext.Provider value={{
            projects,
            internships,
            courses,
            soloPros,
            userStats,
            activities,
            isNewUser,
            enquiries,
            applications,
            rejections,
            getRecommendations,
            handleEnquiry,
            handleApply,
            handleReject,
            addProject,
            addInternship,
            addCourse,
            addActivity,
            activeProjectCheckpoints,
            markCheckpointPaid
        }}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => useContext(DataContext);
