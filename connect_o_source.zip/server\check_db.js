require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function check() {
    try {
        await prisma.$connect();
        console.log('Successfully connected to database');
        process.exit(0);
    } catch (e) {
        console.error('Failed to connect to database:', e.message);
        process.exit(1);
    }
}

check();
