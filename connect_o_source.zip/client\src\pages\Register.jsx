import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import WelcomeModal from '../components/WelcomeModal';

const Register = () => {
    const [searchParams] = useSearchParams();
    const roleParam = searchParams.get('role');
    const roleFromUrl = (roleParam || '').toUpperCase();
    const isTaskMaster = roleFromUrl === 'TASKMASTER';
    const displayRole = isTaskMaster ? 'TaskMaster' : 'SoloPro';
    const isSoloPro = !isTaskMaster;

    // Default form data
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        password: '',
        designation: '',
        position: '',
        experience: '',
        companyName: '',
        role: isTaskMaster ? 'TASKMASTER' : 'SOLOPRO',
        skills: [],
        address: ''
    });

    // EFFECT: Sync formData.role with key URL changes
    useEffect(() => {
        setFormData(prev => ({
            ...prev,
            role: isTaskMaster ? 'TASKMASTER' : 'SOLOPRO'
        }));
    }, [isTaskMaster]);

    const [skillInput, setSkillInput] = useState('');
    const { register } = useAuth();
    const navigate = useNavigate();
    const [showWelcome, setShowWelcome] = useState(false);
    const [businessType, setBusinessType] = useState('business');

    const handleAddSkill = () => {
        const val = skillInput.trim();
        if (val && !formData.skills.includes(val)) {
            setFormData(prev => ({ ...prev, skills: [...prev.skills, val] }));
            setSkillInput('');
        }
    };

    const removeSkill = (skillToRemove) => {
        setFormData(prev => ({ ...prev, skills: prev.skills.filter(s => s !== skillToRemove) }));
    };

    const addPopularSkill = (skill) => {
        if (!formData.skills.includes(skill)) {
            setFormData(prev => ({ ...prev, skills: [...prev.skills, skill] }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await register(formData);
            setShowWelcome(true);
            setTimeout(() => navigate('/dashboard'), 2000);
        } catch (err) {
            console.error("Registration error:", err);
            // Show welcome anyway for demo purposes if backend fails
            setShowWelcome(true);
            setTimeout(() => navigate('/dashboard'), 2000);
        }
    };

    if (showWelcome) {
        return <WelcomeModal role={displayRole.toUpperCase()} onClose={() => navigate('/dashboard')} />;
    }

    const popularSkills = ['React', 'TypeScript', 'Figma', 'Adobe XD', 'Photoshop', 'Illustrator', 'Node.js', 'Python', 'UI/UX Design', 'Graphic Design', 'Web Development', 'Mobile Development', 'Branding', 'Logo Design'];

    return (
        <div className={`min-h-screen py-12 px-4 font-sans flex items-center justify-center ${isSoloPro ? 'bg-[#FFFBF5]' : 'bg-slate-50'}`}>
            {/* Back Link */}
            <div className="absolute top-8 left-8">
                <Link to="/" className={`font-medium flex items-center gap-2 hover:underline ${isSoloPro ? 'text-orange-500' : 'text-blue-600'}`}>
                    ← Back to Home
                </Link>
            </div>

            <div className={`bg-white text-left max-w-2xl w-full p-10 rounded-3xl shadow-xl border border-slate-100 ${!isSoloPro ? 'shadow-blue-100/50' : ''}`}>
                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold text-slate-900">Join as {displayRole}</h1>
                    <p className="text-slate-500 mt-2">
                        {isSoloPro ? 'Showcase your skills and find amazing projects' : 'Connect with talented SoloPros and grow your business'}
                    </p>
                </div>

                {/* Business Type Selector (Only for TaskMaster) */}
                {!isSoloPro && (
                    <div className="mb-8">
                        <label className="block text-sm font-semibold text-slate-700 mb-3">Select Business Type</label>
                        <div className="grid grid-cols-3 gap-4">
                            {[
                                { id: 'business', icon: '🏢', title: 'Business', sub: 'Company or organization' },
                                { id: 'personal', icon: '👤', title: 'Personal', sub: 'Individual projects' },
                                { id: 'other', icon: '💼', title: 'Other Industry', sub: 'Startup or other' }
                            ].map((type) => (
                                <button
                                    key={type.id}
                                    type="button"
                                    onClick={() => setBusinessType(type.id)}
                                    className={`p-4 rounded-xl border text-center transition flex flex-col items-center gap-2 ${businessType === type.id ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500 text-blue-800' : 'border-slate-200 hover:border-slate-300 text-slate-600'}`}
                                >
                                    <span className="text-2xl">{type.icon}</span>
                                    <div>
                                        <div className="font-bold text-sm">{type.title}</div>
                                        <div className="text-[10px] text-slate-400 leading-tight">{type.sub}</div>
                                    </div>
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-5">

                    {/* Full Name Field - Added for BOTH roles */}
                    <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1">Full Name</label>
                        <input
                            type="text"
                            placeholder="John Doe"
                            className={`w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 outline-none text-sm bg-slate-50 focus:bg-white transition ${isSoloPro ? 'focus:ring-orange-500' : 'focus:ring-blue-500'}`}
                            value={formData.name}
                            onChange={e => setFormData({ ...formData, name: e.target.value })}
                            required
                        />
                    </div>

                    {!isSoloPro ? (
                        /* TASKMASTER LAYOUT */
                        <>
                            {/* Row 1: Email & Phone */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Email</label>
                                    <input
                                        type="email"
                                        placeholder="name@company.com"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.email}
                                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                                        required
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Phone</label>
                                    <input
                                        type="tel"
                                        placeholder="+1-555-0123"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.phone}
                                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                                    />
                                </div>
                            </div>

                            {/* Row 2: Address */}
                            <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">Address</label>
                                <input
                                    type="text"
                                    placeholder="123 Main St, City, State, ZIP"
                                    className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                    value={formData.address}
                                    onChange={e => setFormData({ ...formData, address: e.target.value })}
                                />
                            </div>

                            {/* Row 3: Password & Designation */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Password</label>
                                    <input
                                        type="password"
                                        placeholder="••••••"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.password}
                                        onChange={e => setFormData({ ...formData, password: e.target.value })}
                                        required
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Designation</label>
                                    <input
                                        type="text"
                                        placeholder="e.g., Product Manager"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.designation}
                                        onChange={e => setFormData({ ...formData, designation: e.target.value })}
                                    />
                                </div>
                            </div>

                            {/* Row 4: Position & Experience */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Position</label>
                                    <input
                                        type="text"
                                        placeholder="e.g., Senior Manager"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.position}
                                        onChange={e => setFormData({ ...formData, position: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Experience</label>
                                    <input
                                        type="text"
                                        placeholder="e.g., 5 years"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.experience}
                                        onChange={e => setFormData({ ...formData, experience: e.target.value })}
                                    />
                                </div>
                            </div>

                            {/* Row 5: Company Name */}
                            <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">Company Name</label>
                                <input
                                    type="text"
                                    placeholder="e.g., TechCorp Solutions"
                                    className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                    value={formData.companyName}
                                    onChange={e => setFormData({ ...formData, companyName: e.target.value })}
                                />
                            </div>
                        </>
                    ) : (
                        /* SOLOPRO LAYOUT */
                        <>
                            {/* Row 1 */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Email</label>
                                    <input
                                        type="email"
                                        placeholder="name@example.com"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.email}
                                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                                        required
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Password</label>
                                    <input
                                        type="password"
                                        placeholder="••••••"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.password}
                                        onChange={e => setFormData({ ...formData, password: e.target.value })}
                                        required
                                    />
                                </div>
                            </div>

                            {/* Row 2 */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Phone</label>
                                    <input
                                        type="tel"
                                        placeholder="+1-555-0123"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.phone}
                                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-600 mb-1">Designation</label>
                                    <input
                                        type="text"
                                        placeholder="e.g., UI/UX Designer"
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={formData.designation}
                                        onChange={e => setFormData({ ...formData, designation: e.target.value })}
                                    />
                                </div>
                            </div>

                            {/* Experience Dropdown */}
                            <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">Experience</label>
                                <div className="relative">
                                    <select
                                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none text-sm bg-slate-50 focus:bg-white transition appearance-none cursor-pointer"
                                        value={formData.experience}
                                        onChange={e => setFormData({ ...formData, experience: e.target.value })}
                                    >
                                        <option value="" disabled>Select experience level</option>
                                        <option value="Beginner">Beginner (0-2 years)</option>
                                        <option value="Intermediate">Intermediate (3-5 years)</option>
                                        <option value="Expert">Expert (5+ years)</option>
                                    </select>
                                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">▼</div>
                                </div>
                            </div>

                            {/* Skills Tag Engine */}
                            <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">Skills</label>
                                <div className="flex gap-2">
                                    <input
                                        type="text"
                                        placeholder="Type a skill and press Enter"
                                        className="flex-1 px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none text-sm bg-slate-50 focus:bg-white transition"
                                        value={skillInput}
                                        onChange={e => setSkillInput(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), handleAddSkill())}
                                    />
                                    <button
                                        type="button"
                                        onClick={handleAddSkill}
                                        className="bg-orange-500 text-white px-6 font-bold rounded-lg shadow hover:bg-orange-600 transition"
                                    >
                                        Add
                                    </button>
                                </div>
                            </div>

                            {/* Skills List */}
                            <div>
                                <div className="flex flex-wrap gap-2 mb-3">
                                    {formData.skills.map(skill => (
                                        <span key={skill} className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-bold flex items-center gap-2">
                                            {skill}
                                            <button type="button" onClick={() => removeSkill(skill)} className="hover:text-orange-900">×</button>
                                        </span>
                                    ))}
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    <span className="text-xs text-slate-400 py-1">Popular skills:</span>
                                    {popularSkills.map(skill => (
                                        <button
                                            key={skill}
                                            type="button"
                                            onClick={() => addPopularSkill(skill)}
                                            className="px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-semibold border border-slate-200 hover:bg-white hover:border-orange-300 hover:text-orange-600 transition"
                                        >
                                            + {skill}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Resume Upload */}
                            <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">Resume (Optional)</label>
                                <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center cursor-pointer hover:bg-slate-50 hover:border-orange-400 transition group">
                                    <div className="text-3xl mb-2 text-slate-300 group-hover:text-orange-400 transition">⬆️</div>
                                    <p className="text-slate-600 font-bold text-sm">Click to upload your resume</p>
                                    <p className="text-xs text-slate-400 mt-1">PDF, DOC, or DOCX (Max 5MB)</p>
                                </div>
                            </div>
                        </>
                    )}

                    <button
                        type="submit"
                        className={`w-full py-3.5 text-white rounded-lg font-bold shadow-lg mt-6 hover:shadow-xl transition transform hover:scale-[1.01] ${isSoloPro
                                ? 'bg-orange-500 hover:bg-orange-600'
                                : 'bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700'
                            }`}
                    >
                        Create {displayRole} Account
                    </button>

                    <p className="text-center text-sm text-slate-500 mt-4">
                        Already have an account? <Link to="/login" className={`font-bold hover:underline ${isSoloPro ? 'text-orange-600' : 'text-blue-600'}`}>Sign in here</Link>
                    </p>
                </form>
            </div>
        </div>
    );
};

export default Register;
