import { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { motion } from 'framer-motion';
import WorkRoom from './WorkRoom';

const SoloProView = () => {
    const { user } = useAuth();
    const {
        projects,
        internships,
        courses,
        userStats,
        isNewUser,
        addActivity,
        rejections,
        getRecommendations,
        handleEnquiry,
        handleReject
    } = useData();

    const [activeSection, setActiveSection] = useState('Dashboard');
    const [profileImage, setProfileImage] = useState(null);
    const fileInputRef = useRef(null);
    const [appliedJobs, setAppliedJobs] = useState([]);
    const [selectedCourse, setSelectedCourse] = useState(null);
    const [showSyllabus, setShowSyllabus] = useState(false);

    // Internship State
    const [internshipSearch, setInternshipSearch] = useState('');
    const [showApplyModal, setShowApplyModal] = useState(false);
    const [selectedJob, setSelectedJob] = useState(null);
    const [applyForm, setApplyForm] = useState({
        name: '', email: '', contactNumber: '', education: '', workExperience: '', skills: '', resume: null
    });
    const [uploadProgress, setUploadProgress] = useState(0);

    // WorkRoom State
    const [viewMode, setViewMode] = useState('DASHBOARD');
    const [selectedProject, setSelectedProject] = useState(null);

    const openApplyModal = (id, title) => {
        if (appliedJobs.includes(id)) return;
        setSelectedJob({ id, title });
        setApplyForm({ name: '', email: '', contactNumber: '', education: '', workExperience: '', skills: '', resume: null });
        setUploadProgress(0);
        setShowApplyModal(true);
    };

    const handleResumeUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            setApplyForm({ ...applyForm, resume: file });
            let progress = 0;
            const interval = setInterval(() => {
                progress += 20;
                setUploadProgress(progress);
                if (progress >= 100) clearInterval(interval);
            }, 150);
        }
    };

    const submitApplication = (e) => {
        e.preventDefault();
        if (!applyForm.name || !applyForm.email) {
            alert("Please fill in required fields: Name and Email");
            return;
        }
        setAppliedJobs([...appliedJobs, selectedJob.id]);
        alert(`Successfully applied to ${selectedJob.title}!`);
        setShowApplyModal(false);
    };

    const handleImageUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setProfileImage(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const enterWorkRoom = (project) => {
        setSelectedProject(project);
        setViewMode('WORKROOM');
    }

    if (viewMode === 'WORKROOM') {
        return <WorkRoom project={selectedProject} userRole="SOLOPRO" onBack={() => setViewMode('DASHBOARD')} />;
    }

    const renderContent = () => {
        switch (activeSection) {
            case 'Dashboard':
                return (
                    <div className="max-w-6xl mx-auto space-y-8">
                        {/* Welcome Header */}
                        <motion.div
                            initial={{ opacity: 0, y: -20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="flex justify-between items-end p-6 bg-gradient-to-r from-violet-600 to-indigo-600 rounded-3xl shadow-xl text-white relative overflow-hidden"
                        >
                            <div className="relative z-10">
                                <h1 className="text-4xl font-extrabold mb-2">Welcome back, {user?.name.split(' ')[0] || 'SoloPro'}! 🚀</h1>
                                <div className="text-indigo-100 font-medium">You are logged in as a <span className="underline decoration-orange-400 font-black">SoloPro</span>. Discover new projects and level up your skills today.</div>
                            </div>
                            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
                            <div className="absolute bottom-0 left-0 w-40 h-40 bg-purple-500/20 rounded-full blur-2xl -ml-10 -mb-10"></div>
                        </motion.div>

                        {/* Recent Activity */}
                        <div className="lg:col-span-2 bg-white/60 backdrop-blur-md p-8 rounded-3xl border border-white/50 shadow-xl">
                            <h3 className="font-bold text-slate-800 mb-6 text-lg">My Active Jobs</h3>

                            {/* Active Jobs List */}
                            {isNewUser ? (
                                <div className="text-center py-8 bg-white/50 rounded-2xl border border-dashed border-slate-200">
                                    <p className="text-slate-500 font-bold">No active jobs yet.</p>
                                    <p className="text-sm text-slate-400 mt-1">Apply to projects below to get started!</p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex justify-between items-center group hover:shadow-md transition">
                                        <div>
                                            <h4 className="font-bold text-lg text-slate-900">E-commerce Website Redesign</h4>
                                            <p className="text-sm text-slate-500">Client: TechCorp • <span className="text-amber-600 font-bold">In Progress</span></p>
                                        </div>
                                        <button
                                            onClick={() => enterWorkRoom({ id: 101, title: 'E-commerce Website Redesign' })}
                                            className="bg-indigo-600 text-white px-5 py-2 rounded-xl font-bold shadow-lg shadow-indigo-500/30 hover:bg-indigo-700 transition"
                                        >
                                            Enter WorkRoom ⚡
                                        </button>
                                    </div>
                                </div>
                            )}

                        </div>

                        {/* Stats Grid - Colorful Cards */}
                        <div className="grid grid-cols-4 gap-4">
                            {[
                                { label: 'Active Projects', val: isNewUser ? '0' : '3', icon: '↗', grad: 'from-blue-400 to-blue-600' },
                                { label: 'Completed', val: isNewUser ? '0' : '28', icon: '🏆', grad: 'from-amber-400 to-orange-500' },
                                { label: 'EXP Points', val: isNewUser ? '0' : '1,250', icon: '⚡', grad: 'from-fuchsia-500 to-purple-600' },
                                { label: 'This Week', val: isNewUser ? '0' : '2', icon: '📅', grad: 'from-emerald-400 to-teal-600' }
                            ].map((stat, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    transition={{ delay: i * 0.1 }}
                                    className="bg-white/80 backdrop-blur-md p-4 rounded-2xl shadow-lg border border-white/50 flex items-center justify-between hover:transform hover:-translate-y-1 transition duration-300 cursor-pointer"
                                >
                                    <div>
                                        <div className="text-xs text-slate-500 uppercase font-bold tracking-wider">{stat.label}</div>
                                        <div className="text-3xl font-black text-slate-800">{stat.val}</div>
                                    </div>
                                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white text-xl shadow-lg bg-gradient-to-br ${stat.grad}`}>
                                        {stat.icon}
                                    </div>
                                </motion.div>
                            ))}
                        </div>

                        {/* main Split */}
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            {/* Left: Stats & Recommendations (OLX Style) */}
                            <div className="space-y-8">
                                <div className="bg-white/60 backdrop-blur-md p-6 rounded-3xl border border-white/50 shadow-xl space-y-8">
                                    <div>
                                        <h3 className="font-bold text-slate-800 mb-2 text-lg">Current Level</h3>
                                        <div className="flex justify-between text-xs text-slate-500 mb-2 font-semibold">
                                            <span>{isNewUser ? 'Level 1 Rookie' : 'Level 5 Master'}</span>
                                            <span>{isNewUser ? '0 / 100 EXP' : '1250 / 1500 EXP'}</span>
                                        </div>
                                        <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                                            <div
                                                className="bg-gradient-to-r from-violet-500 to-fuchsia-500 h-3 rounded-full animate-pulse"
                                                style={{ width: isNewUser ? '5%' : '85%' }}
                                            ></div>
                                        </div>
                                    </div>
                                </div>

                                {/* "You may also like" - OLX Recommendation Logic */}
                                <div className="bg-white/40 p-4 rounded-3xl border border-white/40">
                                    <h3 className="font-bold text-slate-800 mb-4 px-2 flex items-center justify-between">
                                        <span>You may also like</span>
                                        <span className="text-[10px] text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">Smart Match</span>
                                    </h3>
                                    <div className="space-y-4">
                                        {getRecommendations('PROJECT', ['UI/UX Design', 'React']).slice(0, 3).map(rec => (
                                            <div key={rec.id} className="bg-white p-3 rounded-2xl shadow-sm border border-slate-100 group transition hover:border-orange-200">
                                                <div className="flex justify-between items-start mb-2">
                                                    <h4 className="font-bold text-xs text-slate-800 truncate pr-2">{rec.title}</h4>
                                                    <span className="text-green-600 font-bold text-[10px]">${rec.budget}</span>
                                                </div>
                                                <div className="flex items-center gap-2 mb-3">
                                                    <div className="w-1.5 h-1.5 bg-orange-500 rounded-full"></div>
                                                    <span className="text-[10px] text-slate-500 font-medium">Match: {Math.round(rec.matchWeight)}%</span>
                                                </div>
                                                <div className="grid grid-cols-2 gap-2">
                                                    <button
                                                        onClick={() => handleEnquiry(rec.id, 'SOLOPRO', rec.client)}
                                                        className="text-[10px] bg-slate-50 text-slate-600 font-bold py-1.5 rounded-lg border border-slate-200 hover:bg-white"
                                                    >
                                                        Enquiry
                                                    </button>
                                                    <button
                                                        onClick={() => handleReject(rec.id)}
                                                        className="text-[10px] text-slate-400 hover:text-red-400 font-bold transition"
                                                    >
                                                        Not Interested
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* Available Projects */}
                            <div className="lg:col-span-2">
                                <div className="flex justify-between items-center mb-6">
                                    <h2 className="text-2xl font-bold text-slate-800">Available Projects</h2>
                                    <div className="flex gap-2">
                                        <button className="bg-white text-slate-500 px-4 py-2 rounded-xl text-xs font-bold border border-slate-200">Filter By EXP</button>
                                        <button onClick={() => alert('Browsing all projects...')} className="bg-orange-500 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg shadow-orange-500/30 hover:bg-orange-600 transition flex items-center gap-2">
                                            <span>↗</span> Browse All
                                        </button>
                                    </div>
                                </div>

                                {projects.length === 0 && (
                                    <div className="text-center py-20 bg-white/50 rounded-3xl border-2 border-dashed border-slate-200">
                                        <p className="text-slate-500 font-bold">No projects found matching your profile.</p>
                                        <button className="mt-4 text-orange-600 font-bold underline">Expand search area</button>
                                    </div>
                                )}

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {getRecommendations('PROJECT', ['UI/UX Design', 'React']).map((project) => (
                                        <motion.div
                                            whileHover={{ y: -5 }}
                                            key={project.id}
                                            className={`bg-white rounded-2xl overflow-hidden shadow-lg border transition duration-300 ${rejections.includes(project.id) ? 'opacity-60 border-slate-100 grayscale-[0.5]' : 'border-slate-100 hover:shadow-2xl'}`}
                                        >
                                            {/* Card Header (Orange) */}
                                            <div className="bg-gradient-to-r from-orange-500 to-amber-500 p-4 text-white flex justify-between items-start">
                                                <div>
                                                    <h3 className="font-bold text-lg leading-tight">{project.title}</h3>
                                                    <p className="text-xs opacity-90">{project.type}</p>
                                                </div>
                                                {rejections.includes(project.id) && (
                                                    <span className="bg-black/20 px-2 py-0.5 rounded text-[10px] font-bold">Low Priority</span>
                                                )}
                                            </div>

                                            <div className="p-5 space-y-4">
                                                <p className="text-slate-600 text-xs leading-relaxed line-clamp-2">
                                                    {project.desc}
                                                </p>

                                                <div className="flex justify-between items-center text-sm font-bold">
                                                    <span className="text-green-600">${project.budget}</span>
                                                    <span className="text-slate-400 font-normal text-xs">{project.applicants} applicants</span>
                                                </div>

                                                {/* Tags */}
                                                <div className="flex flex-wrap gap-2">
                                                    {project.tags?.map(tag => (
                                                        <span key={tag} className="px-2 py-0.5 bg-orange-50 text-orange-600 rounded text-[10px] font-bold border border-orange-100">
                                                            {tag}
                                                        </span>
                                                    ))}
                                                </div>

                                                {/* Deadline & Client */}
                                                <div className="flex justify-between items-center text-[10px] text-slate-400 pt-2 border-t border-slate-50">
                                                    <span>Deadline: {project.expiry}</span>
                                                    <span className="font-bold flex items-center gap-1">
                                                        <span>🛡️ By {project.client}</span>
                                                        <span className="bg-blue-50 text-blue-600 px-1 rounded">Trusted</span>
                                                    </span>
                                                </div>

                                                {/* Buttons - Enquiry First Flow */}
                                                <div className="grid grid-cols-2 gap-3 pt-2">
                                                    <button
                                                        onClick={() => handleEnquiry(project.id, 'SOLOPRO', project.client)}
                                                        className="bg-indigo-50 text-indigo-600 py-2 rounded-lg text-xs font-bold hover:bg-indigo-100 transition border border-indigo-100"
                                                    >
                                                        Enquiry 📬
                                                    </button>
                                                    <button
                                                        onClick={() => enterWorkRoom(project)}
                                                        className="bg-orange-500 text-white py-2 rounded-lg text-xs font-bold hover:bg-orange-600 transition shadow-md shadow-orange-200"
                                                    >
                                                        Quick Apply 🚀
                                                    </button>
                                                </div>

                                                {/* Rejection / Less Priority Button */}
                                                {!rejections.includes(project.id) && (
                                                    <button
                                                        onClick={() => handleReject(project.id)}
                                                        className="w-full text-[10px] text-slate-400 font-bold hover:text-slate-600 transition pt-1"
                                                    >
                                                        Show fewer projects like this
                                                    </button>
                                                )}
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                );
            case 'Get Internships':
                const allInternships = [
                    ...internships,
                    { id: 'static-ux', role: 'UX Design Intern', company: 'CreativeMinds', stipend: '$1000/mo', type: 'Hybrid', color: 'bg-purple-500' },
                    { id: 'static-be', role: 'Backend Developer', company: 'ServerSide', stipend: '$1400/mo', type: 'On-site', color: 'bg-green-500' },
                ];
                
                const filteredInternships = allInternships.filter(job => {
                    const searchTerm = internshipSearch.toLowerCase();
                    return job.role?.toLowerCase().includes(searchTerm) || 
                           job.company?.toLowerCase().includes(searchTerm) || 
                           job.type?.toLowerCase().includes(searchTerm);
                });

                return (
                    <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="max-w-6xl mx-auto space-y-8 relative">
                        {showApplyModal && (
                            <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden max-h-[90vh] flex flex-col">
                                    <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
                                        <div>
                                            <h2 className="text-xl font-bold">Apply for {selectedJob?.title}</h2>
                                            <p className="text-sm text-slate-300 mt-1">Complete your application below</p>
                                        </div>
                                        <button onClick={() => setShowApplyModal(false)} className="text-slate-300 hover:text-white text-2xl font-bold">&times;</button>
                                    </div>
                                    <div className="p-6 overflow-y-auto">
                                        <form onSubmit={submitApplication} className="space-y-4">
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                <div>
                                                    <label className="block text-sm font-bold text-slate-700 mb-1">Full Name *</label>
                                                    <input type="text" required value={applyForm.name} onChange={(e) => setApplyForm({...applyForm, name: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" placeholder="John Doe" />
                                                </div>
                                                <div>
                                                    <label className="block text-sm font-bold text-slate-700 mb-1">Email Address *</label>
                                                    <input type="email" required value={applyForm.email} onChange={(e) => setApplyForm({...applyForm, email: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" placeholder="john@example.com" />
                                                </div>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-bold text-slate-700 mb-1">Contact Number</label>
                                                <input type="tel" value={applyForm.contactNumber} onChange={(e) => setApplyForm({...applyForm, contactNumber: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" placeholder="+1 234 567 8900" />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-bold text-slate-700 mb-1">Education Background</label>
                                                <input type="text" value={applyForm.education} onChange={(e) => setApplyForm({...applyForm, education: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" placeholder="B.S. in Computer Science" />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-bold text-slate-700 mb-1">Work Experience</label>
                                                <textarea value={applyForm.workExperience} onChange={(e) => setApplyForm({...applyForm, workExperience: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" rows="2" placeholder="Briefly describe your relevant experience..."></textarea>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-bold text-slate-700 mb-1">Key Skills</label>
                                                <input type="text" value={applyForm.skills} onChange={(e) => setApplyForm({...applyForm, skills: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" placeholder="React, Node.js, Design, etc." />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-bold text-slate-700 mb-1">Resume / CV Upload</label>
                                                <input type="file" onChange={handleResumeUpload} className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
                                                {uploadProgress > 0 && (
                                                    <div className="mt-2 w-full bg-slate-200 rounded-full h-2">
                                                        <div className="bg-indigo-600 h-2 rounded-full transition-all duration-300" style={{ width: `${uploadProgress}%` }}></div>
                                                    </div>
                                                )}
                                            </div>
                                            <div className="pt-4 flex justify-end gap-3">
                                                <button type="button" onClick={() => setShowApplyModal(false)} className="px-6 py-2 rounded-xl font-bold text-slate-600 hover:bg-slate-100">Cancel</button>
                                                <button type="submit" className="px-6 py-2 rounded-xl font-bold bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-600/30">Submit Application</button>
                                            </div>
                                        </form>
                                    </div>
                                </motion.div>
                            </div>
                        )}

                        <div className="flex justify-between items-center bg-teal-500 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
                            <div className="relative z-10">
                                <h1 className="text-3xl font-bold mb-2">Kickstart Your Career today! 🔥</h1>
                                <p className="text-teal-100 max-w-xl">Find the perfect internship to gain experience, build your network, and launch your professional journey.</p>
                                <div className="mt-6 flex gap-2">
                                    <input 
                                        type="text" 
                                        value={internshipSearch}
                                        onChange={(e) => setInternshipSearch(e.target.value)}
                                        placeholder="Job title, keywords..." 
                                        className="px-4 py-3 rounded-xl text-slate-900 outline-none w-64 md:w-80" 
                                    />
                                    {/* Live search based on input change */}
                                </div>
                            </div>
                            <div className="text-[8rem] opacity-20 absolute -right-4 -bottom-8">💼</div>
                        </div>

                        {filteredInternships.length === 0 && (
                            <div className="text-center py-12 bg-white rounded-3xl border border-slate-100 shadow-sm">
                                <p className="text-slate-500 font-bold text-lg">No internships found matching "{internshipSearch}"</p>
                                <button onClick={() => setInternshipSearch('')} className="mt-2 text-teal-600 font-bold hover:underline">Clear Search</button>
                            </div>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {filteredInternships.map((job, i) => {
                                const jobId = job.id || `internship-${i}`;
                                const isApplied = appliedJobs.includes(jobId);
                                return (
                                <div key={jobId} className="bg-white p-6 rounded-2xl shadow-lg border border-slate-100 hover:-translate-y-2 transition duration-300 flex flex-col">
                                    <div className="flex justify-between items-start mb-4">
                                        <div className={`w-12 h-12 ${job.color || 'bg-blue-500'} rounded-xl text-white flex items-center justify-center text-xl font-bold`}>{job.company?.[0] || 'T'}</div>
                                        <span className="bg-slate-100 px-3 py-1 rounded-full text-xs font-bold text-slate-600">{job.type || 'Remote'}</span>
                                    </div>
                                    <h3 className="font-bold text-lg text-slate-800 line-clamp-1">{job.role}</h3>
                                    <p className="text-slate-500 text-sm mb-4 line-clamp-1">{job.company}</p>
                                    <div className="flex gap-2 mb-6 mt-auto">
                                        <span className="bg-green-50 text-green-700 px-2 py-1 rounded text-xs font-bold">{job.stipend || '$500'}</span>
                                        <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs font-bold">3 Months</span>
                                    </div>
                                    <button 
                                        onClick={() => openApplyModal(jobId, job.role)}
                                        disabled={isApplied}
                                        className={`w-full py-2.5 font-bold rounded-xl shadow-md transition ${isApplied ? 'bg-slate-400 text-white cursor-not-allowed' : 'bg-slate-900 text-white hover:bg-slate-700'}`}
                                    >
                                        {isApplied ? 'Applied' : 'Apply Now'}
                                    </button>
                                </div>
                            )})}
                        </div>
                    </motion.div>
                );
            case 'Get Courses':
                const dynamicCourses = (courses || []).map(c => ({
                    id: c.id,
                    title: c.title,
                    author: 'TaskMaster',
                    price: `$${c.price}`,
                    bg: 'bg-indigo-100',
                    icon: '🎓',
                    desc: c.desc
                }));

                const coursesList = [
                    ...dynamicCourses,
                    { title: 'Mastering React 2024', author: 'CodeWithMike', price: '$49', bg: 'bg-cyan-100', icon: '⚛️', syllabus: ['Module 1: React Basics', 'Module 2: Hooks Deep Dive', 'Module 3: State Management', 'Module 4: Performance & Deployment'] },
                    { title: 'UI/UX Design Masterclass', author: 'Sarah Design', price: '$89', bg: 'bg-pink-100', icon: '🎨', syllabus: ['Module 1: Design Thinking', 'Module 2: Wireframing in Figma', 'Module 3: Color & Typography', 'Module 4: Prototyping'] },
                    { title: 'Advanced 3D Animation', author: 'Maya Masters', price: '$79', bg: 'bg-purple-100', icon: '🎬', syllabus: ['Module 1: Intro to Maya & Blender', 'Module 2: Rigging Basics', 'Module 3: Advanced Character Animation', 'Module 4: Rendering & Lighting'] },
                    { title: 'Python for Data Science', author: 'DataCamp', price: '$59', bg: 'bg-green-100', icon: '🐍', syllabus: ['Module 1: Python Crash Course', 'Module 2: Pandas & NumPy', 'Module 3: Data Visualization', 'Module 4: Machine Learning Basics'] },
                ];

                if (selectedCourse) {
                    return (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
                            <button onClick={() => { setSelectedCourse(null); setShowSyllabus(false); }} className="text-slate-500 hover:text-slate-900 font-bold mb-6 flex items-center gap-2">← Back to Courses</button>
                            <div className="flex flex-col md:flex-row gap-8 items-start">
                                <div className={`w-full md:w-64 h-64 ${selectedCourse.bg} rounded-3xl flex items-center justify-center text-7xl shadow-inner shrink-0`}>
                                    {selectedCourse.icon}
                                </div>
                                <div className="flex-1 space-y-5 w-full">
                                    <div className="flex justify-between items-start">
                                        <h1 className="text-3xl font-black text-slate-900">{selectedCourse.title}</h1>
                                        <span className="text-3xl font-black text-orange-500">{selectedCourse.price}</span>
                                    </div>
                                    <p className="text-lg text-slate-500 font-medium tracking-wide">Instructor: {selectedCourse.author}</p>
                                    
                                    <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 text-slate-600 text-sm leading-relaxed">
                                        <strong>About this Course:</strong><br/><br/>
                                        {selectedCourse.desc ? selectedCourse.desc : `This comprehensive course is designed for aspiring and professional individuals who want to master their craft. You will learn industry-standard techniques, workflow optimization, and creative problem solving. Dive deep into advanced concepts with hands-on projects, real-world examples, and step-by-step guidance from ${selectedCourse.author}. Perfect for leveling up your skills!`}
                                    </div>

                                    {showSyllabus && (
                                        <div className="bg-orange-50 p-5 rounded-2xl border border-orange-100 mt-4">
                                            <h3 className="font-bold text-slate-800 mb-3 text-lg">Course Syllabus</h3>
                                            <ul className="space-y-2">
                                                {selectedCourse.syllabus?.map((mod, idx) => (
                                                    <li key={idx} className="flex items-center gap-2 text-sm text-slate-700 font-medium">
                                                        <span className="w-6 h-6 rounded-full bg-orange-200 text-orange-700 flex items-center justify-center text-xs shrink-0">{idx + 1}</span>
                                                        {mod}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}

                                    <div className="flex gap-4 pt-4">
                                        <button onClick={() => alert('Starting Course!')} className="flex-1 py-3.5 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 shadow-xl shadow-slate-900/20 transition transform hover:-translate-y-1">Enroll Now</button>
                                        <button onClick={() => setShowSyllabus(!showSyllabus)} className="px-6 py-3.5 border-2 border-slate-200 text-slate-600 font-bold rounded-xl hover:border-slate-900 hover:text-slate-900 transition flex items-center gap-2">
                                            {showSyllabus ? 'Hide Syllabus' : '📥 Syllabus'}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    );
                }

                return (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-6xl mx-auto space-y-8">
                        <h1 className="text-3xl font-bold text-slate-900">Explore Courses 📚</h1>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            {coursesList.map((course, i) => (
                                <div key={i} className="bg-white rounded-3xl overflow-hidden shadow-xl border border-slate-100 group cursor-pointer hover:shadow-2xl transition flex flex-col">
                                    <div className={`h-40 ${course.bg} flex items-center justify-center text-5xl group-hover:scale-105 transition duration-500`}>
                                        {course.icon}
                                    </div>
                                    <div className="p-5 flex-1 flex flex-col justify-between">
                                        <div>
                                            <div className="flex justify-between items-start mb-2">
                                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide bg-slate-50 px-2 py-1 rounded">Course</span>
                                                <span className="text-orange-500 font-black text-lg">{course.price}</span>
                                            </div>
                                            <h3 className="text-lg font-bold text-slate-900 mb-1 leading-tight">{course.title}</h3>
                                            <p className="text-xs text-slate-500 mb-6">by {course.author}</p>
                                        </div>
                                        <button onClick={() => setSelectedCourse(course)} className="w-full py-2.5 border-2 border-slate-900 text-slate-900 font-bold rounded-xl hover:bg-slate-900 hover:text-white transition shadow-sm text-sm">Preview Course</button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                );
            case 'Profile':
                return (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
                        <div className="h-48 bg-gradient-to-r from-orange-400 to-pink-500 relative"></div>
                        <div className="px-10 pb-10">
                            <div className="relative -mt-16 mb-6 flex justify-between items-end">
                                <div className="w-32 h-32 bg-white rounded-full p-2 shadow-lg relative group">
                                    {profileImage ? (
                                        <img src={profileImage} alt="Profile" className="w-full h-full object-cover rounded-full" />
                                    ) : (
                                        <div className="w-full h-full bg-slate-100 rounded-full flex items-center justify-center text-4xl font-bold text-slate-400">
                                            {user?.name?.[0] || 'SP'}
                                        </div>
                                    )}
                                    <div
                                        onClick={() => fileInputRef.current.click()}
                                        className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition cursor-pointer font-bold text-sm"
                                    >
                                        Change
                                    </div>
                                    <input
                                        type="file"
                                        ref={fileInputRef}
                                        onChange={handleImageUpload}
                                        className="hidden"
                                        accept="image/*"
                                    />
                                </div>
                                <button className="px-6 py-2.5 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 shadow-lg" onClick={() => fileInputRef.current.click()}>
                                    Edit Profile
                                </button>
                            </div>

                            <h1 className="text-3xl font-bold text-slate-900">{user?.name || 'Alex Johnson'}</h1>
                            <p className="text-slate-500 font-medium text-lg">{user?.email || 'fullstack@example.com'} • Full Stack Developer</p>

                            <div className="flex gap-4 mt-6">
                                {['React', 'Node.js', 'Tailwind', 'Figma'].map(skill => (
                                    <span key={skill} className="px-4 py-1.5 bg-slate-100 text-slate-600 font-bold rounded-full text-sm">{skill}</span>
                                ))}
                            </div>

                            <div className="grid grid-cols-3 gap-6 mt-8 border-t border-slate-100 pt-8">
                                <div>
                                    <span className="block text-slate-400 text-xs font-bold uppercase mb-1">Total Earned</span>
                                    <span className="text-2xl font-black text-slate-800">${isNewUser ? 0 : '12,450'}</span>
                                </div>
                                <div>
                                    <span className="block text-slate-400 text-xs font-bold uppercase mb-1">Projects Done</span>
                                    <span className="text-2xl font-black text-slate-800">{isNewUser ? 0 : 28}</span>
                                </div>
                                <div>
                                    <span className="block text-slate-400 text-xs font-bold uppercase mb-1">Level</span>
                                    <span className="text-2xl font-black text-purple-600">{isNewUser ? 'Rookie' : 'Master'}</span>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                );
            default:
                return null;
        }
    }

    return (
        <div className="flex bg-slate-50/50 min-h-screen font-sans">
            {/* Graphical Sidebar */}
            <div className="w-64 bg-white/80 backdrop-blur-xl border-r border-white/50 hidden md:flex flex-col p-6 space-y-4 fixed h-full z-10 left-0 top-16 shadow-2xl">
                <button onClick={() => setActiveSection('Dashboard')} className="w-full py-3 bg-gradient-to-r from-amber-400 to-orange-500 text-white rounded-xl font-bold shadow-lg shadow-orange-500/30 hover:scale-[1.02] transition-transform">
                    SoloPro Dashboard
                </button>
                <nav className="space-y-2 mt-4">
                    {['Dashboard', 'Get Internships', 'Get Courses', 'Profile'].map((item, i) => (
                        <button
                            key={item}
                            onClick={() => setActiveSection(item)}
                            className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl transition font-medium ${activeSection === item ? 'bg-orange-50 text-orange-700 shadow-sm border border-orange-100' : 'text-slate-600 hover:bg-white hover:shadow-md'}`}
                        >
                            <span className="text-xl">{['🏠', '💼', '📚', '👤'][i]}</span> {item}
                        </button>
                    ))}
                </nav>
            </div>

            <div className="flex-1 ml-64 p-8 pt-4">
                {renderContent()}
            </div>
        </div>
    );
};

export default SoloProView;
