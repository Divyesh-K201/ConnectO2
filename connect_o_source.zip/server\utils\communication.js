const PHONE_REGEX = /(\+\d{1,2}\s?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/;
const EMAIL_REGEX = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
const SOCIAL_KEYWORDS = ["whatsapp", "telegram", "instagram", "insta", "signal", "snapchat", "dm me", "contact me at"];

const checkCommunicationViolation = (content) => {
    const lowerContent = content.toLowerCase();

    const hasPhone = PHONE_REGEX.test(content);
    const hasEmail = EMAIL_REGEX.test(content);

    let hasSocial = false;
    for (const keyword of SOCIAL_KEYWORDS) {
        if (lowerContent.includes(keyword)) {
            hasSocial = true;
            break;
        }
    }

    if (hasPhone || hasEmail || hasSocial) {
        const reasons = [];
        if (hasPhone) reasons.push("Phone number detected");
        if (hasEmail) reasons.push("Email address detected");
        if (hasSocial) reasons.push("Social media keyword detected");

        return {
            violation: true,
            reasons
        };
    }

    return { violation: false };
};

module.exports = { checkCommunicationViolation };
