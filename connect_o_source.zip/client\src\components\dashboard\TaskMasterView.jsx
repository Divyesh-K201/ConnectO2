import { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { motion } from 'framer-motion';
import WorkRoom from './WorkRoom';
import ApplicantsView from './ApplicantsView';

const TaskMasterView = () => {
    const { user, logout } = useAuth();
    const {
        projects,
        internships,
        courses,
        activities,
        addProject,
        addInternship,
        addCourse,
        isNewUser,
        enquiries,
        rejections,
        getRecommendations,
        handleEnquiry,
        handleReject
    } = useData();
    const [activeSection, setActiveSection] = useState('Dashboard');
    const [profileImage, setProfileImage] = useState(null);
    const fileInputRef = useRef(null);

    // WorkRoom State
    const [viewMode, setViewMode] = useState('DASHBOARD'); // 'DASHBOARD' | 'WORKROOM' | 'APPLICANTS'
    const [selectedProject, setSelectedProject] = useState(null);

    // Form States
    const [newProject, setNewProject] = useState({ title: '', budget: '', type: 'Web Development', desc: '', skills: '' });
    const [newInternship, setNewInternship] = useState({ role: '', stipend: '', duration: '', desc: '' });
    const [newCourse, setNewCourse] = useState({ title: '', price: '', desc: '' });
    const [selectedCourse, setSelectedCourse] = useState(null);

    // Dummy Stats
    const stats = [
        { label: 'Active Projects', val: projects.length, icon: '📈', color: 'bg-blue-600' },
        { label: 'Total SoloPros', val: isNewUser ? '0' : '156', icon: '👥', color: 'bg-teal-500' },
        { label: 'Completed Projects', val: isNewUser ? '0' : '23', icon: '🏆', color: 'bg-green-500' },
        { label: 'This Month', val: isNewUser ? '0' : '12', icon: '🗂', color: 'bg-purple-500' },
    ];

    const featuredTalent = isNewUser ? [] : [
        { name: 'Sarah Wilson', role: 'UI/UX Designer', exp: '1250 EXP', rating: '4.9', skills: ['Figma', 'Adobe XD', 'Sketch'], avatar: 'S' },
        { name: 'Mike Chen', role: 'Frontend Developer', exp: '2100 EXP', rating: '4.8', skills: ['React', 'TypeScript', 'Tailwind'], avatar: 'M' },
        { name: 'Lisa Rodriguez', role: 'Graphic Designer', exp: '1800 EXP', rating: '4.7', skills: ['Photoshop', 'Illustrator', 'InDesign'], avatar: 'L' },
    ];

    const handleImageUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setProfileImage(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const submitProject = () => {
        if (!newProject.title) return alert('Title required');
        addProject({
            title: newProject.title,
            type: newProject.type,
            budget: newProject.budget,
            desc: newProject.desc,
            tags: newProject.skills.split(',').map(s => s.trim()),
            expiry: '2024-05-01'
        });
        alert('Project Posted Successfully!');
        setActiveSection('Dashboard');
        setNewProject({ title: '', budget: '', type: 'Web Development', desc: '', skills: '' });
    };

    const submitInternship = () => {
        if (!newInternship.role) return alert('Role required');
        addInternship({
            role: newInternship.role,
            stipend: newInternship.stipend,
            days: 0,
            applicants: 0
        });
        alert('Internship Posted Successfully!');
        setNewInternship({ role: '', stipend: '', duration: '', desc: '' });
    };

    const submitCourse = () => {
        if (!newCourse.title || !newCourse.price) return alert('Title and price are required');
        addCourse({
            title: newCourse.title,
            price: newCourse.price,
            desc: newCourse.desc
        });
        alert('Course Uploaded Successfully!');
        setActiveSection('Provide Course');
        setNewCourse({ title: '', price: '', desc: '' });
    };

    const enterWorkRoom = (project) => {
        setSelectedProject(project);
        setViewMode('WORKROOM');
    };

    const viewApplicants = (project) => {
        setSelectedProject(project);
        setViewMode('APPLICANTS');
    };

    // Callback for Applicants View
    const handleHire = (applicant) => {
        alert(`Successfully Hired ${applicant.name}! Redirecting to Workspace...`);
        // In real app, this would update DB and create WorkRoom
        setViewMode('WORKROOM');
    };

    const handleChat = (applicant) => {
        alert(`Opening Secure Pre-Hire Chat with ${applicant.name}...`);
        // In real app, this opens a limited chat
        setViewMode('WORKROOM');
    };

    if (viewMode === 'WORKROOM') {
        return <WorkRoom project={selectedProject} userRole="TASKMASTER" onBack={() => setViewMode('DASHBOARD')} />;
    }

    if (viewMode === 'APPLICANTS') {
        return <ApplicantsView
            project={selectedProject}
            onBack={() => setViewMode('DASHBOARD')}
            onHire={handleHire}
            onChat={handleChat}
        />;
    }

    const renderContent = () => {
        switch (activeSection) {
            case 'Dashboard':
                return (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-7xl mx-auto space-y-10">
                        {/* Header */}
                        <div className="bg-gradient-to-r from-teal-600 to-blue-600 p-8 rounded-3xl shadow-xl text-white mb-10 overflow-hidden relative">
                            <div className="relative z-10">
                                <h1 className="text-4xl font-extrabold mb-2">Welcome back, {user?.name.split(' ')[0] || 'TaskMaster'}! 👋</h1>
                                <p className="text-teal-100 font-medium italic">Role: <span className="font-black underline scale-110 px-2">TaskMaster</span></p>
                                <p className="text-teal-50 mt-4 max-w-xl opacity-90">Manage your projects, hire talent, and scale your business with top-tier SoloPros.</p>
                            </div>
                            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
                        </div>

                        {/* Stats Row */}
                        <div className="grid grid-cols-4 gap-6">
                            {stats.map((stat, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: i * 0.1 }}
                                    className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between hover:shadow-md transition cursor-pointer"
                                >
                                    <div>
                                        <p className="text-xs text-slate-500 font-semibold uppercase">{stat.label}</p>
                                        <p className="text-3xl font-bold text-slate-800 mt-1">{stat.val}</p>
                                    </div>
                                    <div className={`w-12 h-12 ${stat.color} rounded-xl text-white flex items-center justify-center text-xl shadow-lg`}>
                                        {stat.icon}
                                    </div>
                                </motion.div>
                            ))}
                        </div>

                        {/* Active Projects Header */}
                        <div>
                            <div className="flex justify-between items-center mb-4">
                                <h2 className="text-xl font-bold text-slate-900">Your Active Projects</h2>
                                <button onClick={() => setActiveSection('Add Task to Public')} className="px-4 py-2 bg-teal-600 text-white text-sm font-bold rounded-lg shadow hover:bg-teal-700 transition">
                                    + Post New Project
                                </button>
                            </div>

                            {projects.length === 0 ? (
                                <div className="text-center py-10 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl">
                                    <p className="text-slate-500 font-bold">No active projects yet.</p>
                                    <button onClick={() => setActiveSection('Add Task to Public')} className="mt-2 text-teal-600 font-bold hover:underline">Post one now</button>
                                </div>
                            ) : (
                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                    {projects.map((project) => (
                                        <motion.div
                                            key={project.id}
                                            className="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-200 hover:shadow-md transition flex flex-col h-full"
                                        >
                                            <div className="bg-teal-600 p-4 text-white flex justify-between items-center">
                                                <div>
                                                    <h3 className="font-bold text-lg">{project.title}</h3>
                                                    <div className="text-teal-100 text-xs uppercase tracking-wide font-medium">{project.type}</div>
                                                </div>
                                                {/* Status Pill */}
                                                <div className="bg-teal-700/50 px-2 py-1 rounded text-xs font-bold border border-teal-500/30">
                                                    {project.status === 'Active' ? 'In Progress' : 'Collecting Proposals'}
                                                </div>
                                            </div>
                                            <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                                                <p className="text-slate-600 text-sm leading-relaxed">{project.desc}</p>
                                                <div className="flex justify-between items-center font-medium text-sm">
                                                    <span className="text-green-600 font-bold">${project.budget}</span>
                                                    <span className="text-slate-400">{project.applicants} applicants</span>
                                                </div>
                                                <div className="flex flex-wrap gap-2">
                                                    {project.tags?.map(tag => (
                                                        <span key={tag} className="px-2 py-1 bg-slate-100 text-slate-600 text-xs rounded-md border border-slate-200">{tag}</span>
                                                    ))}
                                                </div>
                                                <div className="flex justify-between items-center pt-4 border-t border-slate-100">
                                                    <div className="text-xs text-slate-400">Due: {project.expiry}</div>

                                                    {/* Dynamic Button based on status (Mock logic) */}
                                                    <div className="flex gap-2">
                                                        <button
                                                            onClick={() => viewApplicants(project)}
                                                            className="px-4 py-1.5 bg-white border border-slate-200 text-slate-600 text-sm rounded hover:bg-slate-50 transition font-bold"
                                                        >
                                                            Applicants ({project.applicants})
                                                        </button>
                                                        <button
                                                            onClick={() => enterWorkRoom(project)}
                                                            className="px-4 py-1.5 bg-teal-600 text-white text-sm rounded bg-opacity-90 hover:bg-opacity-100 transition font-bold"
                                                        >
                                                            Workspace
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Rest of dashboard... */}
                        {/* Talent Recommendations & Incoming Alerts */}
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <div className="lg:col-span-2">
                                <div className="flex justify-between items-center mb-6">
                                    <h2 className="text-xl font-bold text-slate-900">Recommended SoloPros</h2>
                                    <span className="text-xs font-bold text-teal-600 bg-teal-50 px-3 py-1 rounded-full">Top Matched Talent</span>
                                </div>

                                <div className="grid grid-cols-2 gap-6">
                                    {getRecommendations('SOLOPRO').map((talent, i) => (
                                        <motion.div
                                            key={i}
                                            whileHover={{ y: -5 }}
                                            className={`bg-white p-6 rounded-2xl shadow-sm border transition text-center relative ${rejections.includes(talent.id) ? 'opacity-60 border-slate-100' : 'border-slate-100 hover:shadow-lg'}`}
                                        >
                                            <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-blue-600 rounded-full mx-auto mb-3 flex items-center justify-center text-xl font-bold text-white shadow-lg">
                                                {talent.avatar}
                                            </div>
                                            <h3 className="font-bold text-slate-900">{talent.name}</h3>
                                            <p className="text-xs text-slate-500 mb-2">{talent.role}</p>
                                            <div className="flex justify-center items-center gap-2 text-xs font-bold text-amber-500 mb-4">
                                                <span>{talent.exp} EXP</span>
                                                <span>•</span>
                                                <span className="flex items-center gap-1">⭐ {talent.rating}</span>
                                            </div>

                                            <div className="flex flex-wrap justify-center gap-1.5 mb-5">
                                                {talent.tags?.map(skill => (
                                                    <span key={skill} className="px-2 py-0.5 bg-slate-50 text-slate-600 text-[10px] font-bold rounded border border-slate-100">{skill}</span>
                                                ))}
                                            </div>

                                            <div className="grid grid-cols-2 gap-2">
                                                <button
                                                    onClick={() => handleEnquiry(talent.id, 'TASKMASTER', talent.name)}
                                                    className="py-2 bg-teal-600 text-white text-xs font-bold rounded hover:bg-teal-700 shadow-md"
                                                >
                                                    Enquiry 📬
                                                </button>
                                                <button
                                                    onClick={() => handleReject(talent.id)}
                                                    className="py-2 bg-slate-50 text-slate-400 text-xs font-bold rounded hover:bg-slate-100 border border-slate-200"
                                                >
                                                    Not Interested
                                                </button>
                                            </div>

                                            <div className="absolute top-4 right-4 bg-teal-50 text-teal-600 text-[9px] font-black px-1.5 py-0.5 rounded border border-teal-100 uppercase">
                                                {Math.round(talent.matchWeight || 0)}% Match
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </div>

                            {/* Incoming Enquiry Alerts */}
                            <div className="bg-white/60 backdrop-blur-md p-6 rounded-3xl border border-white/50 shadow-xl self-start">
                                <h3 className="font-extrabold text-slate-800 mb-6 flex items-center gap-2">
                                    <span>Incoming Enquiries</span>
                                    {enquiries.filter(e => e.from === 'SOLOPRO').length > 0 && (
                                        <span className="w-5 h-5 bg-red-500 text-white text-[10px] flex items-center justify-center rounded-full animate-pulse">
                                            {enquiries.filter(e => e.from === 'SOLOPRO').length}
                                        </span>
                                    )}
                                </h3>

                                {enquiries.filter(e => e.from === 'SOLOPRO').length === 0 ? (
                                    <div className="text-center py-8">
                                        <p className="text-slate-400 text-xs italic">No new enquiries yet.</p>
                                    </div>
                                ) : (
                                    <div className="space-y-4">
                                        {enquiries.filter(e => e.from === 'SOLOPRO').map(enq => (
                                            <div key={enq.id} className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 hover:border-teal-200 transition">
                                                <div className="flex justify-between items-start mb-2">
                                                    <span className="font-bold text-sm text-slate-800">{enq.targetName}</span>
                                                    <span className="text-[9px] text-slate-400">Just now</span>
                                                </div>
                                                <p className="text-[11px] text-slate-500 mb-4 italic">"Interested in your Mobile App Project. Ready to discuss details..."</p>
                                                <button
                                                    onClick={() => alert('Opening Secure Chat... Only available after deposit.')}
                                                    className="w-full py-2 bg-teal-50 text-teal-600 text-xs font-bold rounded-lg hover:bg-teal-100"
                                                >
                                                    View Details
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                <div className="mt-8 pt-6 border-t border-slate-100">
                                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Recommendations Logic</h4>
                                    <div className="space-y-2">
                                        {[
                                            { t: 'High EXP Preference', v: '95%' },
                                            { t: 'Tag Matching Accuracy', v: '88%' },
                                            { t: 'Rotation Diversity', v: 'High' }
                                        ].map((rule, i) => (
                                            <div key={i} className="flex justify-between text-xs font-bold">
                                                <span className="text-slate-500">{rule.t}</span>
                                                <span className="text-teal-600">{rule.v}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Recent Activity */}
                        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                            <h3 className="font-bold text-slate-800 mb-4">Recent Activity</h3>
                            <ul className="space-y-4 text-sm text-slate-600">
                                {activities.map((act, i) => (
                                    <li key={i} className="flex items-center gap-3">
                                        <span className={`w-2 h-2 ${act.color || 'bg-blue-500'} rounded-full`}></span>
                                        <span>{act.text} <span className="text-slate-400 text-xs ml-2">{act.time}</span></span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </motion.div>
                );
            case 'Add Task to Public':
                return (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow-lg border border-slate-100">
                        <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                            <span className="bg-teal-100 text-teal-600 p-2 rounded-lg text-2xl">➕</span>
                            Post a New Project
                        </h2>
                        <div className="space-y-6">
                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-sm font-bold text-slate-700 mb-1">Project Title</label>
                                    <input
                                        type="text"
                                        className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none transition bg-slate-50 focus:bg-white"
                                        placeholder="e.g. Website Redesign"
                                        value={newProject.title}
                                        onChange={e => setNewProject({ ...newProject, title: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-slate-700 mb-1">Budget Range ($)</label>
                                    <input
                                        type="text"
                                        className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none transition bg-slate-50 focus:bg-white"
                                        placeholder="e.g. 500 - 1000"
                                        value={newProject.budget}
                                        onChange={e => setNewProject({ ...newProject, budget: e.target.value })}
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-bold text-slate-700 mb-1">Category</label>
                                <select
                                    className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none transition bg-slate-50 focus:bg-white"
                                    value={newProject.type}
                                    onChange={e => setNewProject({ ...newProject, type: e.target.value })}
                                >
                                    <option>Web Development</option>
                                    <option>Mobile App</option>
                                    <option>UI/UX Design</option>
                                    <option>Branding</option>
                                    <option>Content Writing</option>
                                </select>
                            </div>

                            <div>
                                <label className="block text-sm font-bold text-slate-700 mb-1">Project Description</label>
                                <textarea
                                    className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none h-32 transition bg-slate-50 focus:bg-white"
                                    placeholder="Describe the details, requirements, and scope of your project..."
                                    value={newProject.desc}
                                    onChange={e => setNewProject({ ...newProject, desc: e.target.value })}
                                ></textarea>
                            </div>

                            <div>
                                <label className="block text-sm font-bold text-slate-700 mb-1">Required Skills (Comma separated)</label>
                                <input
                                    type="text"
                                    className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none transition bg-slate-50 focus:bg-white"
                                    placeholder="e.g. React, Figma, Node.js"
                                    value={newProject.skills}
                                    onChange={e => setNewProject({ ...newProject, skills: e.target.value })}
                                />
                            </div>

                            <div className="flex justify-end gap-3 pt-4">
                                <button onClick={() => setActiveSection('Dashboard')} className="px-6 py-3 text-slate-600 font-bold hover:bg-slate-100 rounded-lg transition">Cancel</button>
                                <button onClick={submitProject} className="px-8 py-3 bg-teal-600 text-white font-bold rounded-lg hover:bg-teal-700 shadow-lg shadow-teal-500/30 transition transform hover:scale-105">Submit Project</button>
                            </div>
                        </div>
                    </motion.div>
                );
            case 'Provide Internships':
                return (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-5xl mx-auto space-y-8">
                        {/* Header */}
                        <div className="flex justify-between items-center bg-gradient-to-r from-teal-600 to-emerald-600 p-8 rounded-3xl text-white shadow-lg">
                            <div>
                                <h2 className="text-3xl font-bold mb-2">Provide Internships</h2>
                                <p className="text-teal-100">Find fresh talent and nurture the next generation of pros.</p>
                            </div>
                            <div className="text-6xl">🚀</div>
                        </div>

                        {/* Actions */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {/* Form */}
                            <div className="md:col-span-2 bg-white p-8 rounded-2xl shadow-lg border border-slate-100">
                                <h3 className="font-bold text-xl text-slate-800 mb-6">Create New Internship</h3>
                                <div className="space-y-4">
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Internship Role</label>
                                        <input
                                            type="text"
                                            className="w-full p-3 border rounded-lg bg-slate-50 focus:bg-white transition outline-none focus:ring-2 focus:ring-teal-500"
                                            placeholder="e.g. Frontend Intern"
                                            value={newInternship.role}
                                            onChange={e => setNewInternship({ ...newInternship, role: e.target.value })}
                                        />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Stipend / Salary</label>
                                            <input
                                                type="text"
                                                className="w-full p-3 border rounded-lg bg-slate-50 focus:bg-white transition outline-none focus:ring-2 focus:ring-teal-500"
                                                placeholder="$1000/mo"
                                                value={newInternship.stipend}
                                                onChange={e => setNewInternship({ ...newInternship, stipend: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Duration</label>
                                            <input type="text" className="w-full p-3 border rounded-lg bg-slate-50 focus:bg-white transition outline-none focus:ring-2 focus:ring-teal-500" placeholder="e.g. 3 Months" />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Description & Perks</label>
                                        <textarea className="w-full p-3 border rounded-lg bg-slate-50 focus:bg-white transition outline-none h-24 focus:ring-2 focus:ring-teal-500" placeholder="What will the intern learn?"></textarea>
                                    </div>
                                    <button onClick={submitInternship} className="w-full py-3 bg-teal-600 text-white font-bold rounded-lg hover:bg-teal-700 shadow-md">Post Internship</button>
                                </div>
                            </div>

                            {/* Active List */}
                            <div className="space-y-4">
                                <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-100 h-full">
                                    <h3 className="font-bold text-lg text-slate-800 mb-4">Your Active Internships</h3>
                                    {internships.map((item, i) => (
                                        <div key={i} className="mb-4 pb-4 border-b border-slate-100 last:border-0 last:mb-0">
                                            <div className="font-bold text-slate-800">{item.role}</div>
                                            <div className="flex justify-between text-xs text-slate-500 mt-1">
                                                <span>{item.applicants} Applicants</span>
                                                <span>{item.days}d ago</span>
                                            </div>
                                            <button className="w-full mt-2 py-1.5 text-xs bg-slate-100 text-slate-600 font-bold rounded hover:bg-slate-200">Manage</button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </motion.div>
                );
            case 'Provide Course':
                return (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-6xl mx-auto space-y-8">
                        <div className="bg-slate-900 text-white p-10 rounded-3xl flex justify-between items-center shadow-2xl">
                            <div>
                                <h1 className="text-3xl font-bold mb-2">Share Your Knowledge 🎓</h1>
                                <p className="text-slate-400 max-w-lg">Upload courses to help SoloPros master new skills. Establish yourself as an industry leader.</p>
                                <button onClick={() => setActiveSection('Upload Course')} className="mt-6 px-6 py-3 bg-teal-500 text-slate-900 font-bold rounded-xl hover:bg-teal-400 transition transform hover:-translate-y-1">Start Uploading</button>
                            </div>
                            <div className="text-9xl opacity-20">📼</div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {/* Upload Card */}
                            <div onClick={() => setActiveSection('Upload Course')} className="border-2 border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center p-8 bg-slate-50 hover:bg-slate-100 transition cursor-pointer group">
                                <div className="w-16 h-16 bg-teal-100 text-teal-600 rounded-full flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition">⬆️</div>
                                <span className="font-bold text-slate-600">Upload New Course</span>
                                <span className="text-xs text-slate-400 mt-1">Set Price & Details</span>
                            </div>

                            {/* Existing Courses */}
                            {courses.map(course => (
                                <div key={course.id} className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden group">
                                    <div className="h-40 bg-slate-200 relative flex items-center justify-center">
                                        <div className="text-4xl">🎨</div>
                                    </div>
                                    <div className="p-5">
                                        <h3 className="font-bold text-slate-900 text-lg">{course.title}</h3>
                                        <div className="flex justify-between items-center mt-4 text-sm text-slate-500">
                                            <span>{course.enrolled} Enrolled</span>
                                            <span className="text-teal-600 font-bold">${course.price}</span>
                                        </div>
                                        <button onClick={() => { setSelectedCourse(course); setActiveSection('Course Details'); }} className="w-full mt-4 py-2 border border-slate-200 rounded-lg text-slate-600 font-bold hover:bg-slate-50 transition">View Details</button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                );
            case 'Upload Course':
                return (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow-lg border border-slate-100">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-3">
                                <span className="bg-teal-100 text-teal-600 p-2 rounded-lg text-2xl">⬆️</span>
                                Upload New Course
                            </h2>
                            <button onClick={() => setActiveSection('Provide Course')} className="text-slate-400 hover:text-slate-600 font-bold">Back to Courses</button>
                        </div>
                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-bold text-slate-700 mb-1">Course Title</label>
                                <input
                                    type="text"
                                    className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none transition bg-slate-50 focus:bg-white"
                                    placeholder="e.g. Master React in 30 Days"
                                    value={newCourse.title}
                                    onChange={e => setNewCourse({ ...newCourse, title: e.target.value })}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-slate-700 mb-1">Price Amount ($)</label>
                                <input
                                    type="number"
                                    className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none transition bg-slate-50 focus:bg-white"
                                    placeholder="e.g. 49.99"
                                    value={newCourse.price}
                                    onChange={e => setNewCourse({ ...newCourse, price: e.target.value })}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-slate-700 mb-1">Course Details / Syllabus</label>
                                <textarea
                                    className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none h-32 transition bg-slate-50 focus:bg-white"
                                    placeholder="Describe the course content..."
                                    value={newCourse.desc}
                                    onChange={e => setNewCourse({ ...newCourse, desc: e.target.value })}
                                ></textarea>
                            </div>
                            <div className="flex justify-end gap-3 pt-4">
                                <button onClick={() => setActiveSection('Provide Course')} className="px-6 py-3 text-slate-600 font-bold hover:bg-slate-100 rounded-lg transition">Cancel</button>
                                <button onClick={submitCourse} className="px-8 py-3 bg-teal-600 text-white font-bold rounded-lg hover:bg-teal-700 shadow-lg shadow-teal-500/30 transition transform hover:scale-105">Upload Course</button>
                            </div>
                        </div>
                    </motion.div>
                );
            case 'Course Details':
                if (!selectedCourse) return null;
                return (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto space-y-6">
                        <div className="flex justify-between items-center mb-4">
                            <button onClick={() => setActiveSection('Provide Course')} className="text-teal-600 font-bold hover:underline">← Back to Courses</button>
                        </div>
                        <div className="bg-white rounded-3xl p-8 shadow-lg border border-slate-100">
                            <h2 className="text-3xl font-bold text-slate-900 mb-2">{selectedCourse.title}</h2>
                            <p className="text-slate-500 mb-6">{selectedCourse.desc || 'No specific course description provided.'}</p>
                            
                            <div className="grid grid-cols-3 gap-6 mb-8">
                                <div className="bg-teal-50 p-4 rounded-xl border border-teal-100">
                                    <p className="text-teal-600 text-sm font-bold uppercase">Price</p>
                                    <p className="text-2xl font-black text-slate-900">${selectedCourse.price}</p>
                                </div>
                                <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                                    <p className="text-blue-600 text-sm font-bold uppercase">Total Registered</p>
                                    <p className="text-2xl font-black text-slate-900">{(selectedCourse.enrolled || 0) + (selectedCourse.students?.length || 0)}</p>
                                </div>
                                <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                                    <p className="text-indigo-600 text-sm font-bold uppercase">Currently Enrolled</p>
                                    <p className="text-2xl font-black text-slate-900">{selectedCourse.enrolled || 0}</p>
                                </div>
                            </div>

                            <h3 className="text-xl font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2">Student Details</h3>
                            {selectedCourse.students && selectedCourse.students.length > 0 ? (
                                <div className="space-y-3">
                                    {selectedCourse.students.map((student, i) => (
                                        <div key={i} className="flex justify-between items-center bg-slate-50 p-4 rounded-xl border border-slate-100 hover:border-teal-200 transition">
                                            <div>
                                                <p className="font-bold text-slate-900">{student.name}</p>
                                                <p className="text-sm text-slate-500">{student.email}</p>
                                            </div>
                                            <div className="text-right">
                                                <span className="text-xs font-bold text-slate-400 bg-white px-3 py-1 rounded-full border border-slate-200 shadow-sm">Enrolled on {student.date || 'Recently'}</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-10 bg-slate-50 rounded-xl border border-slate-200 border-dashed">
                                    <p className="text-slate-500 font-bold">No students have enrolled/applied yet.</p>
                                </div>
                            )}
                        </div>
                    </motion.div>
                );
            case 'Profile':
                return (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
                        <div className="h-48 bg-teal-600 relative">
                            <button className="absolute bottom-4 right-4 bg-black/30 text-white px-4 py-2 rounded-lg backdrop-blur-md text-sm font-bold hover:bg-black/40">Edit Cover</button>
                        </div>
                        <div className="px-10 pb-10">
                            <div className="relative -mt-16 mb-6 flex justify-between items-end">
                                <div className="w-32 h-32 bg-white rounded-2xl p-2 shadow-lg relative group">
                                    {profileImage ? (
                                        <img src={profileImage} alt="Profile" className="w-full h-full object-cover rounded-xl" />
                                    ) : (
                                        <div className="w-full h-full bg-slate-100 rounded-xl flex items-center justify-center text-4xl">🏢</div>
                                    )}
                                    <div
                                        onClick={() => fileInputRef.current.click()}
                                        className="absolute inset-0 bg-black/40 rounded-xl flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition cursor-pointer font-bold"
                                    >
                                        Change
                                    </div>
                                    <input
                                        type="file"
                                        ref={fileInputRef}
                                        onChange={handleImageUpload}
                                        className="hidden"
                                        accept="image/*"
                                    />
                                </div>
                                <button className="px-6 py-2.5 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 shadow-lg" onClick={() => fileInputRef.current.click()}>
                                    Upload Photo
                                </button>
                            </div>

                            <h1 className="text-3xl font-bold text-slate-900">{user?.name || 'TechCorp Solutions Inc.'}</h1>
                            <p className="text-slate-500 font-medium">{user?.email || 'contact@techcorp.com'} • {user?.role === 'TASKMASTER' ? 'TaskMaster Account' : 'Member'}</p>

                            <div className="grid grid-cols-3 gap-6 mt-8 border-t border-slate-100 pt-8">
                                <div>
                                    <span className="block text-slate-400 text-xs font-bold uppercase mb-1">Total Projects</span>
                                    <span className="text-2xl font-black text-slate-800">{isNewUser ? 0 : 45}</span>
                                </div>
                                <div>
                                    <span className="block text-slate-400 text-xs font-bold uppercase mb-1">Total Hires</span>
                                    <span className="text-2xl font-black text-slate-800">{isNewUser ? 0 : 128}</span>
                                </div>
                                <div>
                                    <span className="block text-slate-400 text-xs font-bold uppercase mb-1">Rating</span>
                                    <span className="text-2xl font-black text-amber-500">{isNewUser ? 'N/A' : '4.9/5'}</span>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                );
            case 'Account Settings':
                return (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-2xl mx-auto">
                        <h2 className="text-2xl font-bold text-slate-900 mb-6">Account Settings</h2>
                        <div className="bg-white rounded-2xl shadow-lg border border-slate-100 divide-y divide-slate-100">
                            {/* Mock Settings */}
                            {[
                                { title: 'Personal Information', desc: 'Update your name and contact details' },
                                { title: 'Login & Security', desc: 'Change password and 2FA' }
                            ].map((item, i) => (
                                <div key={i} className="p-6 flex justify-between items-center hover:bg-slate-50 cursor-pointer transition">
                                    <div>
                                        <h3 className="font-bold text-slate-800">{item.title}</h3>
                                        <p className="text-sm text-slate-500">{item.desc}</p>
                                    </div>
                                    <span className="text-slate-400 text-xl">›</span>
                                </div>
                            ))}
                        </div>
                        <button onClick={logout} className="mt-8 w-full py-3 bg-red-50 text-red-600 font-bold rounded-xl hover:bg-red-100 transition">Log Out</button>
                    </motion.div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="flex bg-slate-50/50 min-h-screen font-sans">
            {/* Sidebar */}
            <div className="w-64 bg-white/80 backdrop-blur-xl border-r border-white/50 hidden md:flex flex-col p-6 space-y-4 fixed h-full z-10 left-0 top-16 shadow-lg">
                <button onClick={() => setActiveSection('Dashboard')} className="w-full py-3 bg-teal-600 text-white rounded-xl font-bold shadow-lg shadow-teal-500/30 hover:scale-[1.02] transition-transform">
                    TaskMaster Dashboard
                </button>
                <nav className="space-y-2 mt-4">
                    {['Dashboard', 'Add Task to Public', 'Provide Internships', 'Provide Course', 'Profile', 'Account Settings'].map((item, i) => (
                        <button
                            key={item}
                            onClick={() => setActiveSection(item)}
                            className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl transition font-medium ${activeSection === item ? 'bg-teal-50 text-teal-700 shadow-sm border border-teal-100' : 'text-slate-600 hover:bg-white hover:shadow-md'}`}
                        >
                            <span className="text-xl">{['🏠', '➕', '💼', '🎓', '👤', '⚙️'][i]}</span> {item}
                        </button>
                    ))}
                </nav>
            </div>

            {/* Main Content */}
            <div className="flex-1 ml-64 p-8 pt-4">
                {renderContent()}
            </div>
        </div>
    );
};

export default TaskMasterView;
